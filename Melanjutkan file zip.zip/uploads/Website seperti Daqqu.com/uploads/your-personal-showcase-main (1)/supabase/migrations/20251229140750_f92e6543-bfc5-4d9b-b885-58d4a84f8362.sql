-- Enable realtime for website_settings table
ALTER PUBLICATION supabase_realtime ADD TABLE public.website_settings;