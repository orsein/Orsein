-- Allow public read access to orders for the Recent Purchase popup (social proof)
-- This only exposes customer_name, product_name, product_id, and created_at
CREATE POLICY "Allow public read for recent purchases popup"
ON public.orders
FOR SELECT
USING (true);