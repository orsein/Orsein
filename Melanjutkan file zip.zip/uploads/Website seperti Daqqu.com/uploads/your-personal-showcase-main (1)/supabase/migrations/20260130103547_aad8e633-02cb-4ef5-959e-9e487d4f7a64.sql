-- Create table for duration options
CREATE TABLE public.duration_options (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  label TEXT NOT NULL,
  multiplier DECIMAL(5,2) NOT NULL DEFAULT 1.0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.duration_options ENABLE ROW LEVEL SECURITY;

-- Everyone can view active durations
CREATE POLICY "Duration options are viewable by everyone"
ON public.duration_options
FOR SELECT
USING (is_active = true);

-- Admins can manage all duration options
CREATE POLICY "Admins can manage duration options"
ON public.duration_options
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Add trigger for updated_at
CREATE TRIGGER update_duration_options_updated_at
BEFORE UPDATE ON public.duration_options
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default duration options
INSERT INTO public.duration_options (label, multiplier, sort_order) VALUES
  ('1 Bulan', 1.0, 1),
  ('2 Bulan', 1.8, 2),
  ('1 Tahun', 10.0, 3);