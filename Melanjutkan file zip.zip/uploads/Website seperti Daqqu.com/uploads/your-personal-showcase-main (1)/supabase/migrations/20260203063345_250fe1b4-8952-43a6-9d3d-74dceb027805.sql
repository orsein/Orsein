-- Create trigger function to reduce stock when order is inserted
CREATE OR REPLACE FUNCTION public.reduce_stock_on_order()
RETURNS TRIGGER AS $$
BEGIN
  -- Only reduce stock if product_id is provided
  IF NEW.product_id IS NOT NULL THEN
    UPDATE public.products 
    SET stock = stock - NEW.quantity
    WHERE id = NEW.product_id AND stock >= NEW.quantity;
    
    -- Check if stock was actually updated (prevent negative stock)
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Insufficient stock for product %', NEW.product_id;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger to execute after order insert
DROP TRIGGER IF EXISTS trigger_reduce_stock_on_order ON public.orders;
CREATE TRIGGER trigger_reduce_stock_on_order
AFTER INSERT ON public.orders
FOR EACH ROW
EXECUTE FUNCTION public.reduce_stock_on_order();