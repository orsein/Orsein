
-- Drop the restrictive policy and recreate as permissive
DROP POLICY IF EXISTS "Allow public read for recent purchases popup" ON public.orders;

CREATE POLICY "Allow public read for recent purchases popup"
  ON public.orders
  FOR SELECT
  USING (true);
