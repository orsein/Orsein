export interface ProductReview {
  id: number;
  author: string;
  avatar: string;
  rating: number;
  date: string;
  comment: string;
  verified: boolean;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  fullDescription: string;
  price: number;
  originalPrice?: number;
  rating: number;
  category: string;
  images: string[];
  badge?: string;
  features: string[];
  reviews: ProductReview[];
  stock: number;
  specifications?: { label: string; value: string }[];
}

export const products: Product[] = [
  {
    id: 1,
    name: "ChatGPT Plus Account",
    description: "Akses premium ChatGPT-4 dengan fitur lengkap untuk produktivitas maksimal",
    fullDescription: "ChatGPT Plus memberikan akses ke model GPT-4 terbaru dengan kecepatan respons yang lebih cepat dan prioritas akses saat traffic tinggi. Nikmati fitur-fitur canggih seperti analisis gambar, pembuatan kode, dan kemampuan penalaran yang lebih baik. Cocok untuk profesional, pelajar, dan siapa saja yang ingin meningkatkan produktivitas dengan AI.",
    price: 150000,
    originalPrice: 250000,
    rating: 5,
    category: "Produktivitas",
    images: [
      "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1676299081847-824916de030a?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1675557009875-436f7a7c7b12?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1684163761635-0257a1e9e17b?w=800&h=600&fit=crop",
    ],
    badge: "Best Seller",
    stock: 25,
    specifications: [
      { label: "Durasi", value: "1 Bulan" },
      { label: "Tipe Akun", value: "Personal" },
      { label: "Aktivasi", value: "Instan" },
      { label: "Garansi", value: "30 Hari" },
    ],
    features: [
      "Akses GPT-4 tanpa batas",
      "Prioritas saat traffic tinggi",
      "Respons lebih cepat",
      "Analisis gambar & dokumen",
      "Plugin & integrasi",
      "Support 24/7",
    ],
    reviews: [
      {
        id: 1,
        author: "Budi Santoso",
        avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop",
        rating: 5,
        date: "2024-01-15",
        comment: "Sangat membantu pekerjaan saya sebagai content writer. Respons cepat dan akurat!",
        verified: true,
      },
      {
        id: 2,
        author: "Siti Rahayu",
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop",
        rating: 5,
        date: "2024-01-10",
        comment: "Worth every penny! GPT-4 jauh lebih pintar dari versi gratisan.",
        verified: true,
      },
      {
        id: 3,
        author: "Andi Pratama",
        avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop",
        rating: 4,
        date: "2024-01-08",
        comment: "Bagus untuk coding dan debugging. Kadang masih ada error kecil tapi overall mantap.",
        verified: true,
      },
    ],
  },
  {
    id: 2,
    name: "Midjourney Subscription",
    description: "Buat gambar AI berkualitas tinggi untuk desain dan kreativitas",
    fullDescription: "Midjourney adalah tool AI generatif gambar terdepan yang menghasilkan visual stunning dari prompt teks. Dengan subscription ini, Anda dapat membuat unlimited gambar berkualitas tinggi untuk kebutuhan desain, marketing, atau personal projects. Didukung dengan komunitas aktif dan update model terbaru.",
    price: 120000,
    originalPrice: 180000,
    rating: 5,
    category: "Desain",
    images: [
      "https://images.unsplash.com/photo-1686191128892-3b37add60cef?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1684487747720-1ba29cda82f8?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1683009427666-340595e57e43?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1684163761635-0257a1e9e17b?w=800&h=600&fit=crop",
    ],
    badge: "Popular",
    stock: 18,
    specifications: [
      { label: "Durasi", value: "1 Bulan" },
      { label: "Tipe Akun", value: "Basic Plan" },
      { label: "Aktivasi", value: "1-24 Jam" },
      { label: "Garansi", value: "30 Hari" },
    ],
    features: [
      "Unlimited image generation",
      "Akses model V5 terbaru",
      "Resolusi tinggi hingga 4K",
      "Variasi dan upscale",
      "Private mode",
      "Akses Discord komunitas",
    ],
    reviews: [
      {
        id: 1,
        author: "Diana Putri",
        avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop",
        rating: 5,
        date: "2024-01-12",
        comment: "Hasilnya luar biasa! Untuk desain social media jadi lebih mudah dan cepat.",
        verified: true,
      },
      {
        id: 2,
        author: "Rudi Hartono",
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop",
        rating: 5,
        date: "2024-01-09",
        comment: "Sebagai graphic designer, ini sangat membantu untuk brainstorming visual.",
        verified: true,
      },
    ],
  },
  {
    id: 3,
    name: "Canva Pro Lifetime",
    description: "Desain profesional dengan akses ke jutaan template premium",
    fullDescription: "Canva Pro memberikan akses unlimited ke jutaan template premium, foto, video, dan elemen desain. Dengan fitur Brand Kit, Magic Resize, dan Background Remover, Anda dapat membuat desain profesional dalam hitungan menit. Cocok untuk marketer, entrepreneur, dan content creator.",
    price: 85000,
    rating: 4,
    category: "Desain",
    images: [
      "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1626785774573-4b799315345d?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=800&h=600&fit=crop",
    ],
    stock: 50,
    specifications: [
      { label: "Durasi", value: "Lifetime" },
      { label: "Tipe Akun", value: "Pro" },
      { label: "Aktivasi", value: "Instan" },
      { label: "Garansi", value: "Lifetime" },
    ],
    features: [
      "100+ juta foto & video premium",
      "610.000+ template gratis & premium",
      "Brand Kit untuk konsistensi",
      "Magic Resize otomatis",
      "Background Remover",
      "Schedule ke social media",
    ],
    reviews: [
      {
        id: 1,
        author: "Lisa Maharani",
        avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop",
        rating: 5,
        date: "2024-01-14",
        comment: "Template-nya keren banget! Bikin konten IG jadi super mudah.",
        verified: true,
      },
      {
        id: 2,
        author: "Fajar Nugroho",
        avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100&h=100&fit=crop",
        rating: 4,
        date: "2024-01-05",
        comment: "Fitur background remover sangat berguna untuk edit foto produk.",
        verified: true,
      },
    ],
  },
  {
    id: 4,
    name: "Figma Professional",
    description: "Tool kolaborasi desain UI/UX terbaik untuk tim",
    fullDescription: "Figma Professional adalah standar industri untuk desain UI/UX. Dengan fitur real-time collaboration, prototyping, dan design systems, tim Anda dapat bekerja lebih efisien. Termasuk akses ke Figma Community dengan ribuan plugin dan template gratis.",
    price: 175000,
    originalPrice: 220000,
    rating: 5,
    category: "Desain",
    images: [
      "https://images.unsplash.com/photo-1609921212029-bb5a28e60960?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1559028012-481c04fa702d?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1586717791821-3f44a563fa4c?w=800&h=600&fit=crop",
    ],
    stock: 12,
    specifications: [
      { label: "Durasi", value: "1 Bulan" },
      { label: "Tipe Akun", value: "Professional" },
      { label: "Aktivasi", value: "1-24 Jam" },
      { label: "Garansi", value: "30 Hari" },
    ],
    features: [
      "Unlimited projects",
      "Real-time collaboration",
      "Advanced prototyping",
      "Design systems & libraries",
      "Developer handoff",
      "Version history unlimited",
    ],
    reviews: [
      {
        id: 1,
        author: "Kevin Wijaya",
        avatar: "https://images.unsplash.com/photo-1519345182560-3f2917c472ef?w=100&h=100&fit=crop",
        rating: 5,
        date: "2024-01-11",
        comment: "Best design tool ever! Kolaborasi dengan tim jadi seamless.",
        verified: true,
      },
    ],
  },
  {
    id: 5,
    name: "GitHub Copilot",
    description: "AI programming assistant untuk coding lebih cepat dan efisien",
    fullDescription: "GitHub Copilot adalah AI pair programmer yang membantu Anda menulis kode lebih cepat dengan suggestions real-time. Dilatih dengan miliaran baris kode, Copilot memahami konteks project Anda dan memberikan autocomplete yang akurat untuk berbagai bahasa pemrograman.",
    price: 95000,
    rating: 5,
    category: "Coding",
    images: [
      "https://images.unsplash.com/photo-1618401471353-b98afee0b2eb?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1542831371-29b0f74f9713?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&h=600&fit=crop",
    ],
    badge: "New",
    stock: 30,
    specifications: [
      { label: "Durasi", value: "1 Bulan" },
      { label: "Tipe Akun", value: "Individual" },
      { label: "Aktivasi", value: "Instan" },
      { label: "Garansi", value: "30 Hari" },
    ],
    features: [
      "AI code suggestions",
      "Multi-language support",
      "IDE integration",
      "Context-aware completions",
      "Test generation",
      "Documentation helper",
    ],
    reviews: [
      {
        id: 1,
        author: "Dimas Prasetyo",
        avatar: "https://images.unsplash.com/photo-1463453091185-61582044d556?w=100&h=100&fit=crop",
        rating: 5,
        date: "2024-01-13",
        comment: "Produktivitas coding naik 2x lipat! Sangat recommended untuk developer.",
        verified: true,
      },
      {
        id: 2,
        author: "Rina Susanti",
        avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&h=100&fit=crop",
        rating: 5,
        date: "2024-01-07",
        comment: "Membantu banget untuk belajar coding dan explore library baru.",
        verified: true,
      },
    ],
  },
  {
    id: 6,
    name: "Claude Pro Account",
    description: "AI assistant canggih dengan kemampuan analisis dan penulisan superior",
    fullDescription: "Claude Pro dari Anthropic adalah AI assistant dengan kemampuan analisis dan penulisan yang superior. Dengan context window yang sangat besar, Claude dapat memproses dokumen panjang dan memberikan respons yang lebih thoughtful. Ideal untuk research, writing, dan task-task kompleks.",
    price: 165000,
    rating: 5,
    category: "Riset/Pencarian",
    images: [
      "https://images.unsplash.com/photo-1694903110330-cc64b7e1d21d?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1676299081847-824916de030a?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1684163761635-0257a1e9e17b?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1675557009875-436f7a7c7b12?w=800&h=600&fit=crop",
    ],
    stock: 8,
    specifications: [
      { label: "Durasi", value: "1 Bulan" },
      { label: "Tipe Akun", value: "Pro" },
      { label: "Aktivasi", value: "Instan" },
      { label: "Garansi", value: "30 Hari" },
    ],
    features: [
      "Context window 200K tokens",
      "Priority access",
      "File & document analysis",
      "Advanced reasoning",
      "Code understanding",
      "Multilingual support",
    ],
    reviews: [
      {
        id: 1,
        author: "Maya Anggraini",
        avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop",
        rating: 5,
        date: "2024-01-16",
        comment: "Claude lebih natural dalam conversation dan jawabannya lebih mendalam.",
        verified: true,
      },
    ],
  },
  {
    id: 7,
    name: "Adobe Creative Cloud",
    description: "Suite lengkap software kreatif profesional",
    fullDescription: "Adobe Creative Cloud memberikan akses ke semua aplikasi kreatif Adobe termasuk Photoshop, Illustrator, Premiere Pro, After Effects, dan masih banyak lagi. Dengan 100GB cloud storage dan Adobe Fonts, ini adalah toolkit lengkap untuk creative professionals.",
    price: 250000,
    originalPrice: 350000,
    rating: 4,
    category: "Video & Visual",
    images: [
      "https://images.unsplash.com/photo-1562577309-4932fdd64cd1?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1626785774573-4b799315345d?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=800&h=600&fit=crop",
    ],
    stock: 5,
    specifications: [
      { label: "Durasi", value: "1 Bulan" },
      { label: "Tipe Akun", value: "All Apps" },
      { label: "Aktivasi", value: "1-24 Jam" },
      { label: "Garansi", value: "30 Hari" },
    ],
    features: [
      "20+ aplikasi kreatif",
      "100GB cloud storage",
      "Adobe Fonts",
      "Adobe Stock templates",
      "Collaboration tools",
      "Mobile apps",
    ],
    reviews: [
      {
        id: 1,
        author: "Tommy Kurniawan",
        avatar: "https://images.unsplash.com/photo-1507591064344-4c6ce005b128?w=100&h=100&fit=crop",
        rating: 4,
        date: "2024-01-06",
        comment: "Lengkap banget! Semua kebutuhan editing ada di sini.",
        verified: true,
      },
    ],
  },
  {
    id: 8,
    name: "Cursor Pro IDE",
    description: "Code editor AI-powered untuk developer modern",
    fullDescription: "Cursor adalah AI-first code editor yang menggabungkan kekuatan GPT-4 dengan editor yang familiar. Dengan fitur chat, edit, dan generate code, Cursor membantu Anda coding lebih cepat sambil tetap mempertahankan kontrol penuh atas kode Anda.",
    price: 110000,
    rating: 4,
    category: "Coding",
    images: [
      "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1542831371-29b0f74f9713?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&h=600&fit=crop",
      "https://images.unsplash.com/photo-1618401471353-b98afee0b2eb?w=800&h=600&fit=crop",
    ],
    stock: 20,
    specifications: [
      { label: "Durasi", value: "1 Bulan" },
      { label: "Tipe Akun", value: "Pro" },
      { label: "Aktivasi", value: "Instan" },
      { label: "Garansi", value: "30 Hari" },
    ],
    features: [
      "GPT-4 integration",
      "Inline code editing",
      "Codebase chat",
      "Auto-debug",
      "Multi-file editing",
      "VS Code compatible",
    ],
    reviews: [
      {
        id: 1,
        author: "Hendra Gunawan",
        avatar: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=100&h=100&fit=crop",
        rating: 4,
        date: "2024-01-04",
        comment: "Game changer untuk development! AI-nya sangat membantu.",
        verified: true,
      },
    ],
  },
];

export const getProductById = (id: number): Product | undefined => {
  return products.find((p) => p.id === id);
};
