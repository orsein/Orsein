import { Search, CreditCard, MessageCircle, CheckCircle, ArrowRight } from "lucide-react";

const steps = [
  {
    icon: Search,
    title: "Pilih Produk",
    description: "Pilih layanan premium yang Anda butuhkan dari katalog produk kami",
    color: "bg-blue-500",
  },
  {
    icon: CreditCard,
    title: "Pembayaran",
    description: "Lakukan pembayaran mudah via QRIS menggunakan e-wallet atau mobile banking",
    color: "bg-amber-500",
  },
  {
    icon: MessageCircle,
    title: "Konfirmasi",
    description: "Setelah pembayaran, Anda akan diarahkan ke WhatsApp untuk konfirmasi",
    color: "bg-green-500",
  },
  {
    icon: CheckCircle,
    title: "Aktivasi",
    description: "Tim kami akan mengirimkan akses akun Anda dalam waktu 1-24 jam",
    color: "bg-primary",
  },
];

const HowToSubscribeSection = () => {
  return (
    <section id="cara-berlangganan" className="py-16 lg:py-24 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent mb-4">
            <ArrowRight className="w-4 h-4" />
            <span className="text-sm font-medium">Panduan</span>
          </div>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Cara Berlangganan
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Ikuti langkah mudah berikut untuk mulai menikmati layanan premium
          </p>
        </div>

        {/* Steps */}
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step, index) => (
              <div
                key={index}
                className="relative group"
              >
                {/* Connector line for desktop */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-12 left-1/2 w-full h-0.5 bg-gradient-to-r from-border via-primary/30 to-border" />
                )}
                
                <div className="relative bg-card border border-border rounded-2xl p-6 text-center hover:shadow-xl hover:border-primary/30 transition-all duration-300 group-hover:-translate-y-1">
                  {/* Step number */}
                  <div className="absolute -top-3 -right-3 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-bold shadow-lg">
                    {index + 1}
                  </div>

                  {/* Icon */}
                  <div className={`${step.color} w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                    <step.icon className="w-8 h-8 text-white" />
                  </div>

                  {/* Content */}
                  <h3 className="text-lg font-bold text-foreground mb-2">
                    {step.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-12 max-w-3xl mx-auto">
          <div className="bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 rounded-2xl p-6 lg:p-8 border border-primary/20">
            <div className="flex flex-col md:flex-row items-center gap-4 text-center md:text-left">
              <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center flex-shrink-0">
                <MessageCircle className="w-8 h-8 text-primary" />
              </div>
              <div className="flex-1">
                <h4 className="text-lg font-bold text-foreground mb-1">
                  Butuh Bantuan?
                </h4>
                <p className="text-muted-foreground text-sm">
                  Tim support kami siap membantu Anda. Hubungi kami via WhatsApp untuk pertanyaan atau bantuan seputar pemesanan.
                </p>
              </div>
              <a
                href="https://wa.me/6281368968924"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#25D366] hover:bg-[#128C7E] text-white rounded-xl font-medium transition-colors shadow-lg"
              >
                <MessageCircle className="w-5 h-5" />
                Hubungi Kami
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowToSubscribeSection;
