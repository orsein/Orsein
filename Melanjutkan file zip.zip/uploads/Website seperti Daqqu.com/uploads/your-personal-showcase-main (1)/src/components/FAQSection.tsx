import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle } from "lucide-react";

const faqs = [
  {
    question: "Bagaimana cara memesan produk?",
    answer:
      "Pilih produk yang Anda inginkan, klik tombol 'Beli Sekarang' atau tambahkan ke keranjang. Kemudian isi data diri Anda dan lakukan pembayaran via QRIS. Setelah pembayaran dikonfirmasi, kami akan menghubungi Anda via WhatsApp.",
  },
  {
    question: "Berapa lama proses aktivasi setelah pembayaran?",
    answer:
      "Proses aktivasi biasanya dilakukan dalam 1-24 jam setelah pembayaran dikonfirmasi. Untuk jam operasional (09.00-21.00 WIB), aktivasi bisa lebih cepat yaitu 1-3 jam.",
  },
  {
    question: "Metode pembayaran apa saja yang tersedia?",
    answer:
      "Saat ini kami menerima pembayaran melalui QRIS yang bisa dibayar menggunakan berbagai e-wallet seperti GoPay, OVO, Dana, ShopeePay, LinkAja, dan aplikasi mobile banking.",
  },
  {
    question: "Apakah akun yang dijual legal dan aman?",
    answer:
      "Ya, semua akun yang kami jual adalah akun resmi dan legal. Kami menjamin keamanan dan privasi data Anda. Akun dibuat langsung dari layanan resmi masing-masing provider.",
  },
  {
    question: "Bagaimana jika ada masalah dengan akun?",
    answer:
      "Jika Anda mengalami kendala dengan akun, silakan hubungi kami via WhatsApp. Tim support kami akan membantu menyelesaikan masalah Anda maksimal dalam 1x24 jam.",
  },
  {
    question: "Apakah bisa perpanjang langganan?",
    answer:
      "Tentu bisa! Seminggu sebelum masa berlangganan habis, kami akan mengirimkan reminder via WhatsApp. Anda tinggal melakukan pembayaran untuk memperpanjang langganan.",
  },
];

const FAQSection = () => {
  return (
    <section id="faq" className="py-16 lg:py-24 bg-secondary/30">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-4">
            <HelpCircle className="w-4 h-4" />
            <span className="text-sm font-medium">FAQ</span>
          </div>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Temukan jawaban dari pertanyaan yang sering diajukan seputar layanan kami
          </p>
        </div>

        {/* FAQ Accordion */}
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-card border border-border rounded-xl px-6 data-[state=open]:shadow-lg transition-shadow"
              >
                <AccordionTrigger className="text-left font-semibold text-foreground hover:text-primary py-5">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-5 leading-relaxed">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
