import { Mail } from "lucide-react";
import { useWebsiteSettings } from "@/hooks/useWebsiteSettings";

const Footer = () => {
  const { settings } = useWebsiteSettings();

  return (
    <footer id="tentang" className="bg-card border-t border-border py-12">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              {settings.logo_url ? (
                <img src={settings.logo_url} alt={settings.site_name} className="w-10 h-10 rounded-xl object-cover" />
              ) : (
                <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-xl">{settings.site_name.charAt(0)}</span>
                </div>
              )}
              <span className="font-bold text-xl text-foreground">
                {settings.site_name}
              </span>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Marketplace tools AI terpercaya dengan harga terjangkau dan kualitas premium.
            </p>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-bold text-primary text-lg mb-4">Kontak</h3>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Mail className="w-4 h-4" />
              <a href="mailto:support@daqqu.com" className="hover:text-primary transition-colors">
                support@daqqu.com
              </a>
            </div>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-bold text-primary text-lg mb-4">Kategori</h3>
            <ul className="space-y-2">
              <li>
                <a href="#kategori" className="text-muted-foreground hover:text-primary transition-colors">
                  AI Tools
                </a>
              </li>
              <li>
                <a href="#kategori" className="text-muted-foreground hover:text-primary transition-colors">
                  Design Tools
                </a>
              </li>
              <li>
                <a href="#kategori" className="text-muted-foreground hover:text-primary transition-colors">
                  Development Tools
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-border text-center">
          <p className="text-muted-foreground text-sm">
            © {new Date().getFullYear()} {settings.site_name}. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
