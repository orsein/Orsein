import { Button } from "@/components/ui/button";
import { Sparkles, Shield, Zap, HeadphonesIcon, ArrowDown } from "lucide-react";

const features = [
  { icon: Zap, label: "Harga Terjangkau", delay: "0.4s" },
  { icon: Sparkles, label: "Tools Premium", delay: "0.5s" },
  { icon: HeadphonesIcon, label: "Support 24/7", delay: "0.6s" },
  { icon: Shield, label: "Garansi Kualitas", delay: "0.7s" },
];

const Hero = () => {
  return (
    <section id="home" className="pt-28 pb-20 md:pt-36 md:pb-28 gradient-hero">
      <div className="container mx-auto px-4 lg:px-8 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          {/* Eyebrow badge */}
          <div className="animate-fade-in inline-flex items-center gap-2 bg-accent/10 border border-accent/20 text-accent px-4 py-1.5 rounded-full text-sm font-semibold mb-6">
            <Sparkles className="w-4 h-4 animate-shimmer" />
            <span>Marketplace AI Tools #1 di Indonesia</span>
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-7xl font-bold text-foreground mb-6 animate-slide-up leading-[1.1] tracking-tight">
            Akses <span className="text-gradient">AI Premium</span>
            <br className="hidden sm:block" />
            {" "}Harga Terjangkau
          </h1>

          <p
            className="text-base md:text-lg lg:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto animate-slide-up leading-relaxed"
            style={{ animationDelay: "0.15s" }}
          >
            Dapatkan akses ke ChatGPT, Midjourney, Claude Pro, dan tools AI premium lainnya.
            Tingkatkan produktivitas Anda mulai hari ini!
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: "0.25s" }}>
            <Button
              variant="hero"
              size="lg"
              onClick={() => document.getElementById("kategori")?.scrollIntoView({ behavior: "smooth" })}
              className="animate-pulse-soft text-base px-10"
            >
              Mulai Belanja
              <ArrowDown className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </div>

        {/* Feature badges */}
        <div className="mt-16 md:mt-20 grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-5 max-w-3xl mx-auto">
          {features.map((feature, index) => (
            <div
              key={index}
              className="animate-slide-up flex items-center gap-2.5 bg-card/80 backdrop-blur-sm px-4 py-3.5 rounded-2xl shadow-soft border border-border/40 hover:shadow-card hover:border-accent/30 transition-all duration-300 hover:-translate-y-1 group"
              style={{ animationDelay: feature.delay }}
            >
              <div className="w-9 h-9 rounded-xl bg-accent/10 flex items-center justify-center flex-shrink-0 group-hover:bg-accent/20 transition-colors">
                <feature.icon className="w-4.5 h-4.5 text-accent" />
              </div>
              <span className="font-semibold text-sm text-foreground">{feature.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;
