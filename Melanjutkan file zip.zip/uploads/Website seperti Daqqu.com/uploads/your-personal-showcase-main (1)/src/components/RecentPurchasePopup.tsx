import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { X } from "lucide-react";

interface RecentOrder {
  id: string;
  customer_name: string;
  product_name: string;
  product_image: string;
  created_at: string;
}

const RecentPurchasePopup = () => {
  const [orders, setOrders] = useState<RecentOrder[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  // Fetch recent orders with product images
  useEffect(() => {
    const fetchRecentOrders = async () => {
      // Fetch orders
      const { data: ordersData, error: ordersError } = await supabase
        .from("orders")
        .select("id, customer_name, product_name, product_id, created_at")
        .order("created_at", { ascending: false })
        .limit(10);

      if (ordersError) {
        console.error("Error fetching orders:", ordersError);
        return;
      }

      if (!ordersData || ordersData.length === 0) return;

      // Fetch all products to match by name or id
      const { data: productsData } = await supabase
        .from("products")
        .select("id, name, images");

      const productsMap = new Map<string, string>();
      const productsNameMap = new Map<string, string>();
      
      if (productsData) {
        productsData.forEach((product) => {
          const image = product.images?.[0] || "/placeholder.svg";
          productsMap.set(product.id, image);
          // Also map by name (lowercase for flexible matching)
          productsNameMap.set(product.name.toLowerCase(), image);
        });
      }

      const ordersWithImages = ordersData.map((order) => {
        let productImage = "/placeholder.svg";
        
        // First try to get image by product_id
        if (order.product_id && productsMap.has(order.product_id)) {
          productImage = productsMap.get(order.product_id)!;
        } else {
          // Fallback: try to match by product name (partial match)
          const orderProductName = order.product_name.toLowerCase();
          for (const [name, image] of productsNameMap.entries()) {
            if (orderProductName.includes(name) || name.includes(orderProductName.split(" ")[0])) {
              productImage = image;
              break;
            }
          }
        }

        return {
          id: order.id,
          customer_name: maskName(order.customer_name),
          product_name: order.product_name,
          product_image: productImage,
          created_at: order.created_at,
        };
      });

      setOrders(ordersWithImages);
    };

    fetchRecentOrders();
  }, []);

  // Mask customer name for privacy (show first name + initial)
  const maskName = (name: string): string => {
    const parts = name.trim().split(" ");
    if (parts.length === 1) {
      return parts[0];
    }
    return `${parts[0]} ${parts[parts.length - 1].charAt(0)}.`;
  };

  // Calculate time ago in Indonesian
  const getTimeAgo = (dateString: string): string => {
    const now = new Date();
    const date = new Date(dateString);
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    const diffWeeks = Math.floor(diffDays / 7);
    const diffMonths = Math.floor(diffDays / 30);

    if (diffMins < 1) return "Baru saja";
    if (diffMins < 60) return `${diffMins} menit yang lalu`;
    if (diffHours < 24) return `${diffHours} jam yang lalu`;
    if (diffDays < 7) return `${diffDays} hari yang lalu`;
    if (diffWeeks < 4) return `${diffWeeks} minggu yang lalu`;
    return `${diffMonths} bulan yang lalu`;
  };

  // Show popup periodically
  useEffect(() => {
    if (orders.length === 0) return;

    // Initial delay before first popup (shorter for better mobile experience)
    const initialDelay = setTimeout(() => {
      setIsVisible(true);
    }, 3000);

    // Cycle through orders every 10 seconds
    const cycleInterval = setInterval(() => {
      setIsVisible(false);
      
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % orders.length);
        setIsVisible(true);
      }, 500);
    }, 10000);

    return () => {
      clearTimeout(initialDelay);
      clearInterval(cycleInterval);
    };
  }, [orders.length]);

  // Auto-hide after 7 seconds (longer for mobile users to notice)
  useEffect(() => {
    if (!isVisible) return;
    
    const hideTimer = setTimeout(() => {
      setIsVisible(false);
    }, 7000);

    return () => clearTimeout(hideTimer);
  }, [isVisible, currentIndex]);

  if (orders.length === 0 || !orders[currentIndex]) return null;

  const currentOrder = orders[currentIndex];

  return (
    <div
      className={`fixed bottom-4 left-2 right-2 sm:left-4 sm:right-auto z-[9999] transition-all duration-500 ease-out ${
        isVisible
          ? "translate-y-0 opacity-100"
          : "translate-y-full opacity-0 pointer-events-none"
      }`}
      style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
    >
      <div className="bg-white rounded-2xl shadow-2xl border border-border/50 p-3 sm:p-4 max-w-full sm:max-w-[340px] flex items-center gap-3 sm:gap-4 relative ring-1 ring-black/5">
        {/* Product Image */}
        <div className="flex-shrink-0 w-16 h-16 rounded-xl overflow-hidden bg-muted border border-border/30 shadow-sm">
          <img
            src={currentOrder.product_image}
            alt={currentOrder.product_name}
            className="w-full h-full object-cover"
            onError={(e) => {
              (e.target as HTMLImageElement).src = "/placeholder.svg";
            }}
          />
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0 pr-4">
          <p className="text-sm text-foreground leading-snug">
            <span className="font-bold">{currentOrder.customer_name}</span>
            {" "}telah membeli{" "}
            <span className="font-bold text-primary">{currentOrder.product_name}</span>
          </p>
          <p className="text-xs text-muted-foreground mt-1.5">
            {getTimeAgo(currentOrder.created_at)}
          </p>
        </div>

        {/* Close button */}
        <button
          onClick={() => setIsVisible(false)}
          className="absolute top-2 right-2 p-1 text-muted-foreground/60 hover:text-foreground transition-colors rounded-full hover:bg-muted"
          aria-label="Tutup"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
};

export default RecentPurchasePopup;
