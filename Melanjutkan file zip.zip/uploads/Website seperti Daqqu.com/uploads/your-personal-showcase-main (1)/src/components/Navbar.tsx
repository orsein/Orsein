import { useState } from "react";
import { Search, ShoppingCart, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useWebsiteSettings } from "@/hooks/useWebsiteSettings";

interface NavbarProps {
  cartItemCount: number;
  onCartClick: () => void;
}

const Navbar = ({ cartItemCount, onCartClick }: NavbarProps) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { settings } = useWebsiteSettings();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-card/80 backdrop-blur-lg border-b border-border">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2">
            {settings.logo_url ? (
              <img src={settings.logo_url} alt={settings.site_name} className="w-10 h-10 rounded-xl object-cover" />
            ) : (
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-md">
                <span className="text-primary-foreground font-bold text-xl">{settings.site_name.charAt(0)}</span>
              </div>
            )}
            <span className="font-bold text-xl text-foreground">
              {settings.site_name}
            </span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#home" className="text-foreground hover:text-primary transition-colors font-medium">
              Home
            </a>
            <a href="#kategori" className="text-muted-foreground hover:text-primary transition-colors font-medium">
              Kategori
            </a>
            <a href="#cara-berlangganan" className="text-muted-foreground hover:text-primary transition-colors font-medium">
              Cara Berlangganan
            </a>
            <a href="#faq" className="text-muted-foreground hover:text-primary transition-colors font-medium">
              FAQ
            </a>
          </div>

          {/* Right side actions */}
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
              <Search className="w-5 h-5" />
            </Button>

            <Button
              variant="cart"
              size="default"
              onClick={onCartClick}
              className="relative"
            >
              <ShoppingCart className="w-5 h-5" />
              <span className="hidden sm:inline">Keranjang</span>
              {cartItemCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-accent text-accent-foreground text-xs rounded-full flex items-center justify-center font-bold">
                  {cartItemCount}
                </span>
              )}
            </Button>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-border animate-fade-in">
            <div className="flex flex-col gap-4">
              <a href="#home" className="text-foreground hover:text-primary transition-colors font-medium px-2 py-2">
                Home
              </a>
              <a href="#kategori" className="text-muted-foreground hover:text-primary transition-colors font-medium px-2 py-2">
                Kategori
              </a>
              <a href="#cara-berlangganan" className="text-muted-foreground hover:text-primary transition-colors font-medium px-2 py-2">
                Cara Berlangganan
              </a>
              <a href="#faq" className="text-muted-foreground hover:text-primary transition-colors font-medium px-2 py-2">
                FAQ
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
