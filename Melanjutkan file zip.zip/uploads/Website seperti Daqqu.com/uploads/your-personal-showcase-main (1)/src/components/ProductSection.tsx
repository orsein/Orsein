import { useState } from "react";
import { Button } from "@/components/ui/button";
import ProductCard, { Product } from "./ProductCard";
import { useProducts } from "@/hooks/useProducts";
import { Loader2 } from "lucide-react";

const categories = ["Semua", "Coding", "Desain", "Musik & Audio", "Video & Visual", "Presentasi", "Riset/Pencarian", "Produktivitas"];

interface ProductSectionProps {
  onAddToCart: (product: Product) => void;
}

const ProductSection = ({ onAddToCart }: ProductSectionProps) => {
  const [activeCategory, setActiveCategory] = useState("Semua");
  const { data: products = [], isLoading, error } = useProducts();

  const filteredProducts =
    activeCategory === "Semua"
      ? products
      : products.filter((p) => p.category === activeCategory);

  if (isLoading) {
    return (
      <section id="kategori" className="py-16 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-foreground mb-8">
            Produk Unggulan
          </h2>
          <div className="flex justify-center items-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section id="kategori" className="py-16 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-foreground mb-8">
            Produk Unggulan
          </h2>
          <div className="text-center py-12 text-muted-foreground">
            Gagal memuat produk. Silakan coba lagi.
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="kategori" className="py-16 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-foreground mb-8">
          Produk Unggulan
        </h2>

        {/* Category filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              variant={activeCategory === category ? "filter" : "filterOutline"}
              size="pill"
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Product grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            Tidak ada produk dalam kategori ini.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={onAddToCart}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default ProductSection;
