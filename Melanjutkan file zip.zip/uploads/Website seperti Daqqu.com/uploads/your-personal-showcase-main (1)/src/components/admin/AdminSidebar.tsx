import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Settings,
  LogOut,
  Image,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface AdminSidebarProps {
  onSignOut: () => void;
}

const AdminSidebar = ({ onSignOut }: AdminSidebarProps) => {
  const location = useLocation();

  const menuItems = [
    { path: "/admin", label: "Dashboard", icon: LayoutDashboard },
    { path: "/admin/orders", label: "Pesanan", icon: ShoppingCart },
    { path: "/admin/products", label: "Produk", icon: Package },
    { path: "/admin/settings", label: "Pengaturan", icon: Settings },
  ];

  return (
    <aside className="w-64 bg-card border-r border-border min-h-screen flex flex-col">
      <div className="p-6 border-b border-border">
        <Link to="/admin" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-xl">D</span>
          </div>
          <span className="font-bold text-xl text-foreground">Admin</span>
        </Link>
      </div>

      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="p-4 border-t border-border">
        <Button
          variant="ghost"
          className="w-full justify-start text-muted-foreground hover:text-destructive"
          onClick={onSignOut}
        >
          <LogOut className="w-5 h-5 mr-3" />
          Keluar
        </Button>

        <Link to="/" className="block mt-2">
          <Button variant="outline" className="w-full">
            <Image className="w-5 h-5 mr-2" />
            Lihat Website
          </Button>
        </Link>
      </div>
    </aside>
  );
};

export default AdminSidebar;
