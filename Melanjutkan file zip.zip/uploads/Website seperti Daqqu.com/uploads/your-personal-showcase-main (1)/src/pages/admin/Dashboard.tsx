import { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Package, DollarSign, ShoppingCart, Users, Clock, CheckCircle, XCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  customer_phone: string;
  product_name: string;
  total_price: number;
  payment_status: string;
  created_at: string;
}

const Dashboard = () => {
  const [stats, setStats] = useState({
    totalProducts: 0,
    activeProducts: 0,
    totalOrders: 0,
    pendingOrders: 0,
    paidOrders: 0,
    totalRevenue: 0,
  });
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);

  useEffect(() => {
    fetchStats();
    fetchRecentOrders();
  }, []);

  const fetchStats = async () => {
    // Fetch products stats
    const { data: products } = await supabase
      .from("products")
      .select("id, stock, is_active");

    // Fetch orders stats
    const { data: orders } = await supabase
      .from("orders")
      .select("id, payment_status, total_price");

    if (products && orders) {
      const paidOrders = orders.filter((o) => o.payment_status === "paid");
      const totalRevenue = paidOrders.reduce((sum, o) => sum + o.total_price, 0);

      setStats({
        totalProducts: products.length,
        activeProducts: products.filter((p) => p.is_active).length,
        totalOrders: orders.length,
        pendingOrders: orders.filter((o) => o.payment_status === "pending").length,
        paidOrders: paidOrders.length,
        totalRevenue,
      });
    }
  };

  const fetchRecentOrders = async () => {
    const { data } = await supabase
      .from("orders")
      .select("id, order_number, customer_name, customer_phone, product_name, total_price, payment_status, created_at")
      .order("created_at", { ascending: false })
      .limit(10);

    if (data) {
      setRecentOrders(data);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(price);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("id-ID", {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle className="w-3 h-3" />
            Lunas
          </span>
        );
      case "pending":
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-yellow-100 text-yellow-800">
            <Clock className="w-3 h-3" />
            Pending
          </span>
        );
      case "cancelled":
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-800">
            <XCircle className="w-3 h-3" />
            Batal
          </span>
        );
      default:
        return (
          <span className="px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        );
    }
  };

  const statCards = [
    {
      label: "Total Pesanan",
      value: stats.totalOrders,
      icon: ShoppingCart,
      color: "bg-blue-500",
    },
    {
      label: "Pesanan Lunas",
      value: stats.paidOrders,
      icon: CheckCircle,
      color: "bg-green-500",
    },
    {
      label: "Menunggu Bayar",
      value: stats.pendingOrders,
      icon: Clock,
      color: "bg-yellow-500",
    },
    {
      label: "Total Pendapatan",
      value: formatPrice(stats.totalRevenue),
      icon: DollarSign,
      color: "bg-primary",
      isRevenue: true,
    },
    {
      label: "Total Produk",
      value: stats.totalProducts,
      icon: Package,
      color: "bg-indigo-500",
    },
    {
      label: "Produk Aktif",
      value: stats.activeProducts,
      icon: Users,
      color: "bg-teal-500",
    },
  ];

  return (
    <>
      <Helmet>
        <title>Dashboard Admin - Daqqu</title>
      </Helmet>

      <div>
        <h1 className="text-3xl font-bold text-foreground mb-8">Dashboard</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {statCards.map((stat) => (
            <div
              key={stat.label}
              className="bg-card border border-border rounded-xl p-6"
            >
              <div className="flex items-center gap-4">
                <div
                  className={`w-12 h-12 rounded-lg ${stat.color} flex items-center justify-center`}
                >
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <p className="text-muted-foreground text-sm">{stat.label}</p>
                  <p className={`font-bold text-foreground ${stat.isRevenue ? 'text-xl' : 'text-2xl'}`}>
                    {stat.value}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Recent Orders */}
        <div className="mt-8 bg-card border border-border rounded-xl overflow-hidden">
          <div className="p-6 border-b border-border">
            <h2 className="text-xl font-semibold text-foreground">
              Pesanan Terbaru
            </h2>
          </div>
          
          {recentOrders.length === 0 ? (
            <div className="p-8 text-center">
              <ShoppingCart className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">Belum ada pesanan</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left px-6 py-3 text-sm font-semibold text-foreground">No. Pesanan</th>
                    <th className="text-left px-6 py-3 text-sm font-semibold text-foreground">Pelanggan</th>
                    <th className="text-left px-6 py-3 text-sm font-semibold text-foreground">Produk</th>
                    <th className="text-left px-6 py-3 text-sm font-semibold text-foreground">Total</th>
                    <th className="text-left px-6 py-3 text-sm font-semibold text-foreground">Status</th>
                    <th className="text-left px-6 py-3 text-sm font-semibold text-foreground">Tanggal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {recentOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-muted/50">
                      <td className="px-6 py-4 font-mono text-sm text-foreground">{order.order_number}</td>
                      <td className="px-6 py-4">
                        <div className="text-foreground font-medium">{order.customer_name}</div>
                        <div className="text-muted-foreground text-sm">{order.customer_phone}</div>
                      </td>
                      <td className="px-6 py-4 text-foreground">{order.product_name}</td>
                      <td className="px-6 py-4 text-foreground font-medium">{formatPrice(order.total_price)}</td>
                      <td className="px-6 py-4">{getStatusBadge(order.payment_status)}</td>
                      <td className="px-6 py-4 text-muted-foreground text-sm">{formatDate(order.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default Dashboard;
