import { useEffect, useState, useRef } from "react";
import { Helmet } from "react-helmet-async";
import { Plus, Pencil, Trash2, Search, Package, X, Upload, Image as ImageIcon } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

type Product = Database["public"]["Tables"]["products"]["Row"];

interface Specification {
  label: string;
  value: string;
}

const Products = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    full_description: "",
    price: 0,
    original_price: 0,
    category: "Coding",
    badge: "",
    stock: 0,
    features: "",
    is_active: true,
  });
  const [specifications, setSpecifications] = useState<Specification[]>([]);
  const [productImages, setProductImages] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("Gagal memuat produk");
      console.error(error);
    } else {
      setProducts(data || []);
    }
    setIsLoading(false);
  };

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "number" ? Number(value) : value,
    }));
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setFormData((prev) => ({ ...prev, [name]: checked }));
  };

  const openCreateDialog = () => {
    setEditingProduct(null);
    setFormData({
      name: "",
      description: "",
      full_description: "",
      price: 0,
      original_price: 0,
      category: "Coding",
      badge: "",
      stock: 0,
      features: "",
      is_active: true,
    });
    setSpecifications([]);
    setProductImages([]);
    setIsDialogOpen(true);
  };

  const openEditDialog = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      description: product.description || "",
      full_description: product.full_description || "",
      price: product.price,
      original_price: product.original_price || 0,
      category: product.category,
      badge: product.badge || "",
      stock: product.stock,
      features: product.features?.join("\n") || "",
      is_active: product.is_active,
    });
    // Parse specifications from JSONB
    const specs = product.specifications as unknown as Specification[] | null;
    setSpecifications(specs || []);
    setProductImages(product.images || []);
    setIsDialogOpen(true);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    const uploadedUrls: string[] = [];

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
        const filePath = `products/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('images')
          .upload(filePath, file);

        if (uploadError) {
          console.error('Upload error:', uploadError);
          toast.error(`Gagal upload ${file.name}`);
          continue;
        }

        const { data: urlData } = supabase.storage
          .from('images')
          .getPublicUrl(filePath);

        uploadedUrls.push(urlData.publicUrl);
      }

      if (uploadedUrls.length > 0) {
        setProductImages(prev => [...prev, ...uploadedUrls]);
        toast.success(`${uploadedUrls.length} gambar berhasil diupload`);
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Terjadi kesalahan saat upload');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const removeImage = (index: number) => {
    setProductImages(prev => prev.filter((_, i) => i !== index));
  };

  const defaultSpecLabels = ["Durasi", "Tipe Akun", "Aktivasi", "Garansi"];

  const addSpecification = () => {
    setSpecifications([...specifications, { label: "", value: "" }]);
  };

  const addDefaultSpecifications = () => {
    const existingLabels = specifications.map(s => s.label);
    const newSpecs = defaultSpecLabels
      .filter(label => !existingLabels.includes(label))
      .map(label => ({ label, value: "" }));
    setSpecifications([...specifications, ...newSpecs]);
  };

  const updateSpecification = (index: number, field: "label" | "value", value: string) => {
    const updated = [...specifications];
    updated[index][field] = value;
    setSpecifications(updated);
  };

  const removeSpecification = (index: number) => {
    setSpecifications(specifications.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Filter out empty specifications
    const validSpecs = specifications.filter(s => s.label.trim() && s.value.trim());

    const productData = {
      name: formData.name,
      description: formData.description,
      full_description: formData.full_description,
      price: formData.price,
      original_price: formData.original_price || null,
      category: formData.category,
      badge: formData.badge || null,
      stock: formData.stock,
      features: formData.features.split("\n").filter((f) => f.trim()),
      specifications: validSpecs as unknown as Database["public"]["Tables"]["products"]["Row"]["specifications"],
      is_active: formData.is_active,
      images: productImages.length > 0 ? productImages : null,
    };

    if (editingProduct) {
      const { error } = await supabase
        .from("products")
        .update(productData)
        .eq("id", editingProduct.id);

      if (error) {
        toast.error("Gagal mengupdate produk");
        console.error(error);
      } else {
        toast.success("Produk berhasil diupdate");
        setIsDialogOpen(false);
        fetchProducts();
      }
    } else {
      const { error } = await supabase.from("products").insert([productData]);

      if (error) {
        toast.error("Gagal menambah produk");
        console.error(error);
      } else {
        toast.success("Produk berhasil ditambahkan");
        setIsDialogOpen(false);
        fetchProducts();
      }
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Yakin ingin menghapus produk ini?")) return;

    const { error } = await supabase.from("products").delete().eq("id", id);

    if (error) {
      toast.error("Gagal menghapus produk");
      console.error(error);
    } else {
      toast.success("Produk berhasil dihapus");
      fetchProducts();
    }
  };

  const filteredProducts = products.filter((p) =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <>
      <Helmet>
        <title>Kelola Produk - Admin Daqqu</title>
      </Helmet>

      <div>
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-foreground">Kelola Produk</h1>
          <Button onClick={openCreateDialog}>
            <Plus className="w-5 h-5 mr-2" />
            Tambah Produk
          </Button>
        </div>

        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Cari produk..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-12 bg-card border border-border rounded-xl">
            <Package className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">Belum ada produk</p>
          </div>
        ) : (
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted">
                <tr>
                  <th className="text-left px-6 py-4 text-sm font-semibold text-foreground">
                    Produk
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-semibold text-foreground">
                    Kategori
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-semibold text-foreground">
                    Harga
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-semibold text-foreground">
                    Stok
                  </th>
                  <th className="text-left px-6 py-4 text-sm font-semibold text-foreground">
                    Status
                  </th>
                  <th className="text-right px-6 py-4 text-sm font-semibold text-foreground">
                    Aksi
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredProducts.map((product) => (
                  <tr key={product.id} className="hover:bg-muted/50">
                    <td className="px-6 py-4">
                      <div className="font-medium text-foreground">
                        {product.name}
                      </div>
                      {product.badge && (
                        <span className="text-xs bg-accent text-accent-foreground px-2 py-0.5 rounded">
                          {product.badge}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-muted-foreground">
                      {product.category}
                    </td>
                    <td className="px-6 py-4 text-foreground font-medium">
                      {formatPrice(product.price)}
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`font-medium ${
                          product.stock === 0
                            ? "text-red-500"
                            : product.stock <= 5
                            ? "text-yellow-500"
                            : "text-green-500"
                        }`}
                      >
                        {product.stock}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`px-2 py-1 rounded text-xs font-medium ${
                          product.is_active
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {product.is_active ? "Aktif" : "Nonaktif"}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEditDialog(product)}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive"
                          onClick={() => handleDelete(product.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingProduct ? "Edit Produk" : "Tambah Produk"}
              </DialogTitle>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nama Produk *</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Kategori</Label>
                  <select
                    id="category"
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
                  >
                    <option value="Coding">Coding</option>
                    <option value="Desain">Desain</option>
                    <option value="Musik & Audio">Musik & Audio</option>
                    <option value="Video & Visual">Video & Visual</option>
                    <option value="Presentasi">Presentasi</option>
                    <option value="Riset/Pencarian">Riset/Pencarian</option>
                    <option value="Produktivitas">Produktivitas</option>
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Deskripsi Singkat</Label>
                <Input
                  id="description"
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="full_description">Deskripsi Lengkap</Label>
                <Textarea
                  id="full_description"
                  name="full_description"
                  value={formData.full_description}
                  onChange={handleInputChange}
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price">Harga *</Label>
                  <Input
                    id="price"
                    name="price"
                    type="number"
                    value={formData.price}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="original_price">Harga Coret</Label>
                  <Input
                    id="original_price"
                    name="original_price"
                    type="number"
                    value={formData.original_price}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="stock">Stok *</Label>
                  <Input
                    id="stock"
                    name="stock"
                    type="number"
                    value={formData.stock}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="badge">Badge (opsional)</Label>
                <Input
                  id="badge"
                  name="badge"
                  placeholder="Contoh: Best Seller, Promo"
                  value={formData.badge}
                  onChange={handleInputChange}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="features">Fitur (satu per baris)</Label>
                <Textarea
                  id="features"
                  name="features"
                  placeholder="Fitur 1&#10;Fitur 2&#10;Fitur 3"
                  value={formData.features}
                  onChange={handleInputChange}
                  rows={4}
                />
              </div>

              {/* Image Upload Section */}
              <div className="space-y-3">
                <Label>Gambar Produk</Label>
                <div className="border-2 border-dashed border-border rounded-lg p-4">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleImageUpload}
                    className="hidden"
                    id="image-upload"
                  />
                  <div className="flex flex-col items-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isUploading}
                    >
                      {isUploading ? (
                        <>
                          <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin mr-2" />
                          Mengupload...
                        </>
                      ) : (
                        <>
                          <Upload className="w-4 h-4 mr-2" />
                          Upload Gambar
                        </>
                      )}
                    </Button>
                    <p className="text-xs text-muted-foreground">
                      PNG, JPG, WEBP (Maks. beberapa file)
                    </p>
                  </div>
                </div>

                {productImages.length > 0 && (
                  <div className="grid grid-cols-4 gap-2 mt-3">
                    {productImages.map((url, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={url}
                          alt={`Product ${index + 1}`}
                          className="w-full h-20 object-cover rounded-lg border border-border"
                        />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3 h-3" />
                        </button>
                        {index === 0 && (
                          <span className="absolute bottom-1 left-1 text-[10px] bg-primary text-primary-foreground px-1 rounded">
                            Utama
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                {productImages.length === 0 && (
                  <div className="flex items-center justify-center py-4 bg-muted/30 rounded-lg">
                    <ImageIcon className="w-8 h-8 text-muted-foreground mr-2" />
                    <span className="text-sm text-muted-foreground">Belum ada gambar</span>
                  </div>
                )}
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Spesifikasi Produk</Label>
                  <div className="flex gap-2">
                    <Button type="button" variant="secondary" size="sm" onClick={addDefaultSpecifications}>
                      Template Default
                    </Button>
                    <Button type="button" variant="outline" size="sm" onClick={addSpecification}>
                      <Plus className="w-4 h-4 mr-1" />
                      Tambah
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  {specifications.map((spec, index) => (
                    <div key={index} className="flex gap-2 items-center">
                      <select
                        value={spec.label}
                        onChange={(e) => updateSpecification(index, "label", e.target.value)}
                        className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm w-[140px]"
                      >
                        <option value="">Pilih Label</option>
                        <option value="Durasi">Durasi</option>
                        <option value="Tipe Akun">Tipe Akun</option>
                        <option value="Aktivasi">Aktivasi</option>
                        <option value="Garansi">Garansi</option>
                        <option value="custom">Lainnya...</option>
                      </select>
                      {spec.label === "custom" || !defaultSpecLabels.includes(spec.label) && spec.label !== "" ? (
                        <Input
                          placeholder="Label custom"
                          value={spec.label === "custom" ? "" : spec.label}
                          onChange={(e) => updateSpecification(index, "label", e.target.value)}
                          className="w-[120px]"
                        />
                      ) : null}
                      <Input
                        placeholder={
                          spec.label === "Durasi" ? "cth: 1 Bulan" :
                          spec.label === "Tipe Akun" ? "cth: Basic Plan" :
                          spec.label === "Aktivasi" ? "cth: 1-24 Jam" :
                          spec.label === "Garansi" ? "cth: 30 Hari" :
                          "Nilai"
                        }
                        value={spec.value}
                        onChange={(e) => updateSpecification(index, "value", e.target.value)}
                        className="flex-1"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeSpecification(index)}
                        className="text-destructive shrink-0"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                  {specifications.length === 0 && (
                    <div className="text-center py-4 border border-dashed border-border rounded-lg">
                      <p className="text-sm text-muted-foreground mb-2">
                        Belum ada spesifikasi
                      </p>
                      <Button type="button" variant="outline" size="sm" onClick={addDefaultSpecifications}>
                        Gunakan Template Default
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="is_active"
                  name="is_active"
                  checked={formData.is_active}
                  onChange={handleCheckboxChange}
                  className="h-4 w-4"
                />
                <Label htmlFor="is_active">Produk Aktif</Label>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                >
                  Batal
                </Button>
                <Button type="submit">
                  {editingProduct ? "Simpan Perubahan" : "Tambah Produk"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default Products;
