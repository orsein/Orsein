import { useState } from "react";
import { Plus, Pencil, Trash2, GripVertical, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  useAllDurations,
  useCreateDuration,
  useUpdateDuration,
  useDeleteDuration,
  DurationOption,
} from "@/hooks/useDurations";

const Durations = () => {
  const { data: durations, isLoading } = useAllDurations();
  const createDuration = useCreateDuration();
  const updateDuration = useUpdateDuration();
  const deleteDuration = useDeleteDuration();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingDuration, setEditingDuration] = useState<DurationOption | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    label: "",
    multiplier: 1,
    sort_order: 0,
    is_active: true,
  });

  const resetForm = () => {
    setFormData({
      label: "",
      multiplier: 1,
      sort_order: 0,
      is_active: true,
    });
    setEditingDuration(null);
  };

  const handleOpenDialog = (duration?: DurationOption) => {
    if (duration) {
      setEditingDuration(duration);
      setFormData({
        label: duration.label,
        multiplier: duration.multiplier,
        sort_order: duration.sort_order,
        is_active: duration.is_active,
      });
    } else {
      resetForm();
      // Set default sort order to be after the last item
      if (durations && durations.length > 0) {
        const maxOrder = Math.max(...durations.map((d) => d.sort_order));
        setFormData((prev) => ({ ...prev, sort_order: maxOrder + 1 }));
      }
    }
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (editingDuration) {
      await updateDuration.mutateAsync({
        id: editingDuration.id,
        ...formData,
      });
    } else {
      await createDuration.mutateAsync(formData);
    }

    setIsDialogOpen(false);
    resetForm();
  };

  const handleDelete = async () => {
    if (deleteId) {
      await deleteDuration.mutateAsync(deleteId);
      setDeleteId(null);
    }
  };

  const handleToggleActive = async (duration: DurationOption) => {
    await updateDuration.mutateAsync({
      id: duration.id,
      is_active: !duration.is_active,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Durasi Produk</h1>
          <p className="text-muted-foreground">
            Kelola opsi durasi dan pengali harga untuk produk
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="w-4 h-4 mr-2" />
              Tambah Durasi
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingDuration ? "Edit Durasi" : "Tambah Durasi Baru"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="label">Label Durasi</Label>
                <Input
                  id="label"
                  value={formData.label}
                  onChange={(e) =>
                    setFormData({ ...formData, label: e.target.value })
                  }
                  placeholder="Contoh: 1 Bulan, 3 Bulan, 1 Tahun"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="multiplier">Pengali Harga</Label>
                <Input
                  id="multiplier"
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={formData.multiplier}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      multiplier: parseFloat(e.target.value) || 1,
                    })
                  }
                  required
                />
                <p className="text-xs text-muted-foreground">
                  Harga produk akan dikalikan dengan nilai ini. Contoh: 1.8
                  berarti harga × 1.8
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="sort_order">Urutan</Label>
                <Input
                  id="sort_order"
                  type="number"
                  min="0"
                  value={formData.sort_order}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      sort_order: parseInt(e.target.value) || 0,
                    })
                  }
                  required
                />
                <p className="text-xs text-muted-foreground">
                  Angka lebih kecil akan tampil lebih dulu
                </p>
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="is_active">Aktif</Label>
                <Switch
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(checked) =>
                    setFormData({ ...formData, is_active: checked })
                  }
                />
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsDialogOpen(false);
                    resetForm();
                  }}
                >
                  Batal
                </Button>
                <Button
                  type="submit"
                  disabled={
                    createDuration.isPending || updateDuration.isPending
                  }
                >
                  {createDuration.isPending || updateDuration.isPending ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : null}
                  {editingDuration ? "Simpan" : "Tambah"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12"></TableHead>
              <TableHead>Label</TableHead>
              <TableHead>Pengali Harga</TableHead>
              <TableHead>Urutan</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Aksi</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {durations && durations.length > 0 ? (
              durations.map((duration) => (
                <TableRow key={duration.id}>
                  <TableCell>
                    <GripVertical className="w-4 h-4 text-muted-foreground" />
                  </TableCell>
                  <TableCell className="font-medium">
                    {duration.label}
                  </TableCell>
                  <TableCell>×{duration.multiplier}</TableCell>
                  <TableCell>{duration.sort_order}</TableCell>
                  <TableCell>
                    <Switch
                      checked={duration.is_active}
                      onCheckedChange={() => handleToggleActive(duration)}
                    />
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleOpenDialog(duration)}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteId(duration.id)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8">
                  <p className="text-muted-foreground">
                    Belum ada durasi. Klik "Tambah Durasi" untuk membuat.
                  </p>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Durasi?</AlertDialogTitle>
            <AlertDialogDescription>
              Tindakan ini tidak dapat dibatalkan. Durasi akan dihapus secara
              permanen.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Hapus
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Durations;
