import { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Search, ShoppingCart, Eye, Clock, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";

interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  customer_email: string | null;
  customer_phone: string;
  customer_address: string | null;
  product_id: string | null;
  product_name: string;
  product_price: number;
  quantity: number;
  total_price: number;
  payment_method: string;
  payment_status: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

const Orders = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      toast.error("Gagal memuat pesanan");
      console.error(error);
    } else {
      setOrders(data || []);
    }
    setIsLoading(false);
  };

  const updateStatus = async (orderId: string, newStatus: string) => {
    const { error } = await supabase
      .from("orders")
      .update({ payment_status: newStatus })
      .eq("id", orderId);

    if (error) {
      toast.error("Gagal mengubah status");
      console.error(error);
    } else {
      toast.success("Status berhasil diubah");
      fetchOrders();
      if (selectedOrder?.id === orderId) {
        setSelectedOrder({ ...selectedOrder, payment_status: newStatus });
      }
    }
  };

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.order_number.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer_phone.includes(searchQuery);
    
    const matchesStatus = statusFilter === "all" || order.payment_status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(price);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("id-ID", {
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "paid":
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle className="w-3 h-3" />
            Lunas
          </span>
        );
      case "pending":
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-yellow-100 text-yellow-800">
            <Clock className="w-3 h-3" />
            Pending
          </span>
        );
      case "cancelled":
        return (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-800">
            <XCircle className="w-3 h-3" />
            Batal
          </span>
        );
      default:
        return (
          <span className="px-2 py-1 rounded text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        );
    }
  };

  const openDetail = (order: Order) => {
    setSelectedOrder(order);
    setIsDetailOpen(true);
  };

  return (
    <>
      <Helmet>
        <title>Kelola Pesanan - Admin Daqqu</title>
      </Helmet>

      <div>
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-foreground">Kelola Pesanan</h1>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Cari pesanan, nama, atau telepon..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="h-10 rounded-md border border-input bg-background px-3 py-2 text-sm"
          >
            <option value="all">Semua Status</option>
            <option value="pending">Pending</option>
            <option value="paid">Lunas</option>
            <option value="cancelled">Batal</option>
          </select>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
          </div>
        ) : filteredOrders.length === 0 ? (
          <div className="text-center py-12 bg-card border border-border rounded-xl">
            <ShoppingCart className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">Belum ada pesanan</p>
          </div>
        ) : (
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted">
                  <tr>
                    <th className="text-left px-6 py-4 text-sm font-semibold text-foreground">No. Pesanan</th>
                    <th className="text-left px-6 py-4 text-sm font-semibold text-foreground">Pelanggan</th>
                    <th className="text-left px-6 py-4 text-sm font-semibold text-foreground">Produk</th>
                    <th className="text-left px-6 py-4 text-sm font-semibold text-foreground">Total</th>
                    <th className="text-left px-6 py-4 text-sm font-semibold text-foreground">Status</th>
                    <th className="text-left px-6 py-4 text-sm font-semibold text-foreground">Tanggal</th>
                    <th className="text-right px-6 py-4 text-sm font-semibold text-foreground">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filteredOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-muted/50">
                      <td className="px-6 py-4 font-mono text-sm text-foreground">{order.order_number}</td>
                      <td className="px-6 py-4">
                        <div className="text-foreground font-medium">{order.customer_name}</div>
                        <div className="text-muted-foreground text-sm">{order.customer_phone}</div>
                      </td>
                      <td className="px-6 py-4 text-foreground">{order.product_name}</td>
                      <td className="px-6 py-4 text-foreground font-medium">{formatPrice(order.total_price)}</td>
                      <td className="px-6 py-4">{getStatusBadge(order.payment_status)}</td>
                      <td className="px-6 py-4 text-muted-foreground text-sm">
                        {new Date(order.created_at).toLocaleDateString("id-ID", {
                          day: "numeric",
                          month: "short",
                          year: "numeric",
                        })}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex justify-end">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openDetail(order)}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Order Detail Dialog */}
        <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Detail Pesanan</DialogTitle>
            </DialogHeader>

            {selectedOrder && (
              <div className="space-y-4">
                <div className="bg-muted rounded-lg p-4">
                  <div className="font-mono text-lg font-bold text-foreground mb-1">
                    {selectedOrder.order_number}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {formatDate(selectedOrder.created_at)}
                  </div>
                </div>

                <div className="space-y-3">
                  <h3 className="font-semibold text-foreground">Info Pelanggan</h3>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="text-muted-foreground">Nama</div>
                    <div className="text-foreground">{selectedOrder.customer_name}</div>
                    <div className="text-muted-foreground">Telepon</div>
                    <div className="text-foreground">{selectedOrder.customer_phone}</div>
                    {selectedOrder.customer_email && (
                      <>
                        <div className="text-muted-foreground">Email</div>
                        <div className="text-foreground">{selectedOrder.customer_email}</div>
                      </>
                    )}
                    {selectedOrder.customer_address && (
                      <>
                        <div className="text-muted-foreground">Alamat</div>
                        <div className="text-foreground">{selectedOrder.customer_address}</div>
                      </>
                    )}
                  </div>
                </div>

                <div className="space-y-3">
                  <h3 className="font-semibold text-foreground">Detail Produk</h3>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div className="text-muted-foreground">Produk</div>
                    <div className="text-foreground">{selectedOrder.product_name}</div>
                    <div className="text-muted-foreground">Harga</div>
                    <div className="text-foreground">{formatPrice(selectedOrder.product_price)}</div>
                    <div className="text-muted-foreground">Jumlah</div>
                    <div className="text-foreground">{selectedOrder.quantity}</div>
                    <div className="text-muted-foreground font-semibold">Total</div>
                    <div className="text-foreground font-bold">{formatPrice(selectedOrder.total_price)}</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h3 className="font-semibold text-foreground">Status Pembayaran</h3>
                  <div className="flex items-center gap-2">
                    {getStatusBadge(selectedOrder.payment_status)}
                    <span className="text-sm text-muted-foreground">
                      via {selectedOrder.payment_method}
                    </span>
                  </div>
                </div>

                {selectedOrder.notes && (
                  <div className="space-y-2">
                    <h3 className="font-semibold text-foreground">Catatan</h3>
                    <p className="text-sm text-muted-foreground">{selectedOrder.notes}</p>
                  </div>
                )}

                <div className="flex gap-2 pt-4 border-t border-border">
                  {selectedOrder.payment_status === "pending" && (
                    <>
                      <Button
                        className="flex-1"
                        onClick={() => updateStatus(selectedOrder.id, "paid")}
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Tandai Lunas
                      </Button>
                      <Button
                        variant="destructive"
                        onClick={() => updateStatus(selectedOrder.id, "cancelled")}
                      >
                        <XCircle className="w-4 h-4 mr-2" />
                        Batalkan
                      </Button>
                    </>
                  )}
                  {selectedOrder.payment_status === "cancelled" && (
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => updateStatus(selectedOrder.id, "pending")}
                    >
                      <Clock className="w-4 h-4 mr-2" />
                      Kembalikan ke Pending
                    </Button>
                  )}
                  {selectedOrder.payment_status === "paid" && (
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => updateStatus(selectedOrder.id, "pending")}
                    >
                      <Clock className="w-4 h-4 mr-2" />
                      Kembalikan ke Pending
                    </Button>
                  )}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default Orders;
