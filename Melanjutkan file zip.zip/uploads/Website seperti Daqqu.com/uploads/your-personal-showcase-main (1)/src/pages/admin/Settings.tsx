import { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Save, Upload, Image, Phone, Palette } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

interface Settings {
  logo_url: string;
  qris_image_url: string;
  whatsapp_number: string;
  site_name: string;
  primary_color: string;
}

const Settings = () => {
  const [settings, setSettings] = useState<Settings>({
    logo_url: "",
    qris_image_url: "",
    whatsapp_number: "",
    site_name: "",
    primary_color: "#002b2f",
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingQris, setUploadingQris] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from("website_settings")
      .select("key, value");

    if (error) {
      toast.error("Gagal memuat pengaturan");
      console.error(error);
    } else if (data) {
      const settingsMap: Record<string, string> = {};
      data.forEach((item) => {
        settingsMap[item.key] = item.value || "";
      });
      setSettings({
        logo_url: settingsMap.logo_url || "",
        qris_image_url: settingsMap.qris_image_url || "",
        whatsapp_number: settingsMap.whatsapp_number || "",
        site_name: settingsMap.site_name || "",
        primary_color: settingsMap.primary_color || "#002b2f",
      });
    }
    setIsLoading(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setSettings((prev) => ({ ...prev, [name]: value }));
  };

  const upsertWebsiteSettings = async (updates: Array<{ key: string; value: string }>) => {
    // NOTE: website_settings.key memiliki unique constraint, jadi aman pakai upsert.
    const { error } = await supabase
      .from("website_settings")
      .upsert(updates, { onConflict: "key" });

    if (error) throw error;
  };

  const uploadImage = async (
    file: File,
    folder: string
  ): Promise<string | null> => {
    const fileExt = file.name.split(".").pop();
    const fileName = `${folder}/${Date.now()}.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from("images")
      .upload(fileName, file);

    if (uploadError) {
      console.error("Upload error:", uploadError);
      return null;
    }

    const { data } = supabase.storage.from("images").getPublicUrl(fileName);
    return data.publicUrl;
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingLogo(true);
    const url = await uploadImage(file, "logo");

    if (url) {
      setSettings((prev) => ({ ...prev, logo_url: url }));
      try {
        await upsertWebsiteSettings([{ key: "logo_url", value: url }]);
        toast.success("Logo berhasil diupload & disimpan");
      } catch (error) {
        console.error("Save logo_url error:", error);
        toast.error("Logo terupload, tapi gagal disimpan. Coba klik 'Simpan Pengaturan'.");
      }
    } else {
      toast.error("Gagal mengupload logo");
    }
    setUploadingLogo(false);
  };

  const handleQrisUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingQris(true);
    const url = await uploadImage(file, "qris");

    if (url) {
      setSettings((prev) => ({ ...prev, qris_image_url: url }));
      try {
        await upsertWebsiteSettings([{ key: "qris_image_url", value: url }]);
        toast.success("QRIS berhasil diupload & disimpan");
      } catch (error) {
        console.error("Save qris_image_url error:", error);
        toast.error("QRIS terupload, tapi gagal disimpan. Coba klik 'Simpan Pengaturan'.");
      }
    } else {
      toast.error("Gagal mengupload QRIS");
    }
    setUploadingQris(false);
  };

  const handleSave = async () => {
    setIsSaving(true);

    try {
      const updates = Object.entries(settings).map(([key, value]) => ({
        key,
        value,
      }));

      await upsertWebsiteSettings(updates);

      toast.success("Pengaturan berhasil disimpan");
    } catch (error) {
      console.error("Save error:", error);
      toast.error("Gagal menyimpan pengaturan");
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Pengaturan Website - Admin Daqqu</title>
      </Helmet>

      <div>
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold text-foreground">
            Pengaturan Website
          </h1>
          <Button onClick={handleSave} disabled={isSaving}>
            <Save className="w-5 h-5 mr-2" />
            {isSaving ? "Menyimpan..." : "Simpan Pengaturan"}
          </Button>
        </div>

        <div className="grid gap-6">
          {/* Logo Settings */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center gap-2">
              <Image className="w-5 h-5 text-primary" />
              Logo Website
            </h2>

            <div className="flex items-start gap-6">
              <div className="w-32 h-32 bg-muted rounded-xl flex items-center justify-center border-2 border-dashed border-border overflow-hidden">
                {settings.logo_url ? (
                  <img
                    src={settings.logo_url}
                    alt="Logo"
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <Image className="w-12 h-12 text-muted-foreground" />
                )}
              </div>

              <div className="flex-1 space-y-4">
                <div className="space-y-2">
                  <Label>Upload Logo Baru</Label>
                  <div className="flex gap-2">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      disabled={uploadingLogo}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Format: PNG, JPG. Ukuran maksimal: 2MB
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="logo_url">Atau masukkan URL Logo</Label>
                  <Input
                    id="logo_url"
                    name="logo_url"
                    value={settings.logo_url}
                    onChange={handleInputChange}
                    placeholder="https://example.com/logo.png"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* QRIS Settings */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center gap-2">
              <Upload className="w-5 h-5 text-primary" />
              Gambar QRIS Pembayaran
            </h2>

            <div className="flex items-start gap-6">
              <div className="w-48 h-48 bg-white rounded-xl flex items-center justify-center border-2 border-dashed border-border overflow-hidden">
                {settings.qris_image_url ? (
                  <img
                    src={settings.qris_image_url}
                    alt="QRIS"
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="text-center text-muted-foreground">
                    <Image className="w-12 h-12 mx-auto mb-2" />
                    <span className="text-sm">Upload QRIS</span>
                  </div>
                )}
              </div>

              <div className="flex-1 space-y-4">
                <div className="space-y-2">
                  <Label>Upload Gambar QRIS</Label>
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleQrisUpload}
                    disabled={uploadingQris}
                  />
                  <p className="text-xs text-muted-foreground">
                    Upload gambar QR Code pembayaran QRIS Anda
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="qris_image_url">
                    Atau masukkan URL Gambar QRIS
                  </Label>
                  <Input
                    id="qris_image_url"
                    name="qris_image_url"
                    value={settings.qris_image_url}
                    onChange={handleInputChange}
                    placeholder="https://example.com/qris.png"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* General Settings */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center gap-2">
              <Palette className="w-5 h-5 text-primary" />
              Pengaturan Umum
            </h2>

            <div className="grid gap-4">
              <div className="space-y-2">
                <Label htmlFor="site_name">Nama Website</Label>
                <Input
                  id="site_name"
                  name="site_name"
                  value={settings.site_name}
                  onChange={handleInputChange}
                  placeholder="Daqqu"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="primary_color">Warna Utama</Label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    id="primary_color"
                    name="primary_color"
                    value={settings.primary_color}
                    onChange={handleInputChange}
                    className="w-12 h-10 rounded border border-border cursor-pointer"
                  />
                  <Input
                    value={settings.primary_color}
                    onChange={handleInputChange}
                    name="primary_color"
                    placeholder="#002b2f"
                    className="flex-1"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* WhatsApp Settings */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center gap-2">
              <Phone className="w-5 h-5 text-primary" />
              Pengaturan WhatsApp
            </h2>

            <div className="space-y-2">
              <Label htmlFor="whatsapp_number">Nomor WhatsApp</Label>
              <Input
                id="whatsapp_number"
                name="whatsapp_number"
                value={settings.whatsapp_number}
                onChange={handleInputChange}
                placeholder="6281234567890"
              />
              <p className="text-xs text-muted-foreground">
                Format: Kode negara + nomor tanpa tanda + (contoh: 6281234567890)
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Settings;
