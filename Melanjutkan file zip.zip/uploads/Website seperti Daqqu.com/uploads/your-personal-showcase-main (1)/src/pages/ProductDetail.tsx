import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import {
  ArrowLeft,
  ShoppingCart,
  Check,
  Share2,
  Heart,
  Package,
  Tag,
  Clock,
  Shield,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CartSidebar, { CartItem } from "@/components/CartSidebar";
import ImageGallery from "@/components/ImageGallery";
import { useProductById } from "@/hooks/useProducts";
import { useDurations } from "@/hooks/useDurations";

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { data: product, isLoading, error } = useProductById(id || "");
  const { data: durationOptions = [], isLoading: durationsLoading } = useDurations();

  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [selectedDurationId, setSelectedDurationId] = useState<string>("");

  // Set default duration when durations are loaded
  useEffect(() => {
    if (durationOptions.length > 0 && !selectedDurationId) {
      setSelectedDurationId(durationOptions[0].id);
    }
  }, [durationOptions, selectedDurationId]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(price);
  };

  const handleUpdateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity < 1) return;
    setCartItems((prev) =>
      prev.map((item) =>
        item.id === productId ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== productId));
    toast.info("Produk dihapus dari keranjang");
  };

  const cartItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleShare = async () => {
    try {
      await navigator.share({
        title: product?.name || "Produk",
        text: product?.description || "",
        url: window.location.href,
      });
    } catch {
      navigator.clipboard.writeText(window.location.href);
      toast.success("Link berhasil disalin!");
    }
  };

  if (isLoading || durationsLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">
            Produk tidak ditemukan
          </h1>
          <Link to="/">
            <Button variant="default">Kembali ke Beranda</Button>
          </Link>
        </div>
      </div>
    );
  }

  const currentDuration = durationOptions.find((d) => d.id === selectedDurationId);
  const multiplier = currentDuration?.multiplier ?? 1;
  const adjustedPrice = Math.round(product.price * multiplier);
  const adjustedOriginalPrice = product.originalPrice
    ? Math.round(product.originalPrice * multiplier)
    : null;

  const discount = adjustedOriginalPrice
    ? Math.round(
        ((adjustedOriginalPrice - adjustedPrice) / adjustedOriginalPrice) * 100
      )
    : 0;

  const handleAddToCart = () => {
    if (product.stock === 0) {
      toast.error("Maaf, stok produk sedang habis");
      return;
    }
    
    setCartItems((prev) => {
      const existingItem = prev.find((item) => item.id === product.id);
      if (existingItem) {
        toast.success(`Jumlah ${product.name} ditambahkan`);
        return prev.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      toast.success(`${product.name} ditambahkan ke keranjang`);
      const newItem: CartItem = {
        id: product.id,
        name: `${product.name} (${currentDuration?.label || "1 Bulan"})`,
        price: adjustedPrice,
        image: product.images[0] || "/placeholder.svg",
        quantity,
      };
      return [...prev, newItem];
    });
  };

  return (
    <>
      <Helmet>
        <title>{product.name} - Daqqu</title>
        <meta name="description" content={product.description} />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar
          cartItemCount={cartItemCount}
          onCartClick={() => setCartOpen(true)}
        />

        <main className="pt-24 pb-16">
          <div className="container mx-auto px-4 lg:px-8">
            {/* Breadcrumb */}
            <div className="mb-8">
              <Link
                to="/"
                className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Kembali ke Produk</span>
              </Link>
            </div>

            {/* Product Content */}
            <div className="grid lg:grid-cols-2 gap-12 mb-16">
              {/* Image Gallery */}
              <ImageGallery 
                images={product.images.length > 0 ? product.images : ["/placeholder.svg"]} 
                productName={product.name} 
              />

              {/* Product Info */}
              <div className="space-y-6">
                {/* Badge & Category */}
                <div className="flex items-center gap-3">
                  <span className="text-sm text-primary font-medium">
                    {product.category}
                  </span>
                  {product.badge && (
                    <span className="bg-accent text-accent-foreground text-xs font-bold px-3 py-1 rounded-full">
                      {product.badge}
                    </span>
                  )}
                </div>

                {/* Title */}
                <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                  {product.name}
                </h1>


                {/* Duration Options */}
                <div className="space-y-3">
                  <h3 className="font-semibold text-foreground">Pilih Durasi</h3>
                  <div className="flex flex-wrap gap-3">
                    {durationOptions.map((duration) => (
                      <button
                        key={duration.id}
                        onClick={() => setSelectedDurationId(duration.id)}
                        className={`px-5 py-3 rounded-xl border-2 font-medium transition-all ${
                          selectedDurationId === duration.id
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border bg-background text-muted-foreground hover:border-primary/50"
                        }`}
                      >
                        {duration.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Price */}
                <div className="flex items-baseline gap-4">
                  <span className="text-3xl font-bold text-primary">
                    {formatPrice(adjustedPrice)}
                  </span>
                  {adjustedOriginalPrice && (
                    <>
                      <span className="text-xl text-muted-foreground line-through">
                        {formatPrice(adjustedOriginalPrice)}
                      </span>
                      <span className="bg-destructive text-destructive-foreground text-sm font-bold px-3 py-1 rounded-full">
                        Hemat {discount}%
                      </span>
                    </>
                  )}
                </div>

                {/* Description */}
                <p className="text-muted-foreground leading-relaxed text-lg">
                  {product.fullDescription}
                </p>

                {/* Stock Status */}
                <div className="flex items-center gap-3">
                  <div
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                      product.stock > 10
                        ? "bg-primary/10 text-primary"
                        : product.stock > 0
                        ? "bg-accent/20 text-accent-foreground"
                        : "bg-destructive/10 text-destructive"
                    }`}
                  >
                    <Package className="w-4 h-4" />
                    <span className="font-medium">
                      {product.stock > 10
                        ? `Stok Tersedia (${product.stock})`
                        : product.stock > 0
                        ? `Stok Terbatas (${product.stock})`
                        : "Stok Habis"}
                    </span>
                  </div>
                </div>

                {/* Specifications */}
                {product.specifications && product.specifications.length > 0 && (
                  <div className="bg-muted/30 rounded-xl p-6 border border-border/50">
                    <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                      <Tag className="w-5 h-5 text-primary" />
                      Spesifikasi Produk
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      {product.specifications.map((spec, index) => (
                        <div
                          key={index}
                          className="flex items-center gap-3 text-sm"
                        >
                          {spec.label === "Durasi" && (
                            <Clock className="w-4 h-4 text-muted-foreground" />
                          )}
                          {spec.label === "Tipe Akun" && (
                            <Tag className="w-4 h-4 text-muted-foreground" />
                          )}
                          {spec.label === "Aktivasi" && (
                            <Package className="w-4 h-4 text-muted-foreground" />
                          )}
                          {spec.label === "Garansi" && (
                            <Shield className="w-4 h-4 text-muted-foreground" />
                          )}
                          <div>
                            <span className="text-muted-foreground">
                              {spec.label}:
                            </span>{" "}
                            <span className="font-medium text-foreground">
                              {spec.value}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Features */}
                {product.features && product.features.length > 0 && (
                  <div className="bg-muted/50 rounded-xl p-6">
                    <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                      <Check className="w-5 h-5 text-primary" />
                      Fitur Utama
                    </h3>
                    <div className="grid sm:grid-cols-2 gap-3">
                      {product.features.map((feature, index) => (
                        <div
                          key={index}
                          className="flex items-center gap-3 bg-background/60 rounded-lg px-4 py-3 border border-border/30"
                        >
                          <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0" />
                          <span className="text-foreground text-sm">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quantity & Add to Cart */}
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex items-center border border-border rounded-lg">
                    <button
                      onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                      className="px-4 py-3 text-foreground hover:bg-muted transition-colors disabled:opacity-50"
                      disabled={product.stock === 0}
                    >
                      -
                    </button>
                    <span className="px-6 py-3 font-medium text-foreground">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                      className="px-4 py-3 text-foreground hover:bg-muted transition-colors disabled:opacity-50"
                      disabled={product.stock === 0 || quantity >= product.stock}
                    >
                      +
                    </button>
                  </div>
                  <Button
                    variant="default"
                    size="lg"
                    className="flex-1"
                    onClick={handleAddToCart}
                    disabled={product.stock === 0}
                  >
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    {product.stock === 0 ? "Stok Habis" : "Tambah ke Keranjang"}
                  </Button>
                </div>

                {/* Action buttons */}
                <div className="flex gap-3">
                  <Button variant="outline" size="lg" onClick={handleShare}>
                    <Share2 className="w-4 h-4 mr-2" />
                    Bagikan
                  </Button>
                  <Button variant="outline" size="lg">
                    <Heart className="w-4 h-4 mr-2" />
                    Wishlist
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </main>

        <Footer />

        <CartSidebar
          isOpen={cartOpen}
          onClose={() => setCartOpen(false)}
          items={cartItems}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveItem={handleRemoveItem}
        />
      </div>
    </>
  );
};

export default ProductDetail;
