import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import {
  ArrowLeft,
  User,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  MessageCircle,
  CheckCircle,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { CartItem } from "@/components/CartSidebar";
import { useWebsiteSettings } from "@/hooks/useWebsiteSettings";
import { supabase } from "@/integrations/supabase/client";
// URL gambar QRIS Logo
const QRIS_LOGO_URL = "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/QRIS_logo.svg/1200px-QRIS_logo.svg.png";

const Checkout = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { settings } = useWebsiteSettings();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    address: "",
  });

  const [selectedPayment, setSelectedPayment] = useState<string>("");

  useEffect(() => {
    const items = location.state?.cartItems as CartItem[] | undefined;
    if (items && items.length > 0) {
      setCartItems(items);
    } else {
      navigate("/");
    }
  }, [location.state, navigate]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(price);
  };

  const total = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const generateOrderMessage = () => {
    const orderItems = cartItems
      .map(
        (item) =>
          `• ${item.name} x${item.quantity} = ${formatPrice(item.price * item.quantity)}`
      )
      .join("\n");

    const paymentMethod = selectedPayment === "qris" ? "QRIS" : "-";

    return `🛒 *PESANAN BARU*

📋 *Detail Pembeli:*
Nama: ${formData.name}
No. HP: ${formData.phone}
Email: ${formData.email}
Alamat: ${formData.address}

🛍️ *Produk yang Dipesan:*
${orderItems}

💰 *Total: ${formatPrice(total)}*

💳 *Metode Pembayaran:* ${paymentMethod}

Mohon konfirmasi pesanan ini. Terima kasih! 🙏`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.phone || !formData.email) {
      toast.error("Mohon lengkapi data pembeli");
      return;
    }

    if (!selectedPayment) {
      toast.error("Mohon pilih metode pembayaran");
      return;
    }

    setIsSubmitting(true);

    try {
      // Save orders to database
      for (const item of cartItems) {
        const tempOrderNumber = `ORD-TEMP-${Date.now()}-${Math.random().toString(36).substring(7)}`;
        
        const { error } = await supabase.from("orders").insert([{
          order_number: tempOrderNumber,
          customer_name: formData.name,
          customer_phone: formData.phone,
          customer_email: formData.email,
          customer_address: formData.address || null,
          product_id: item.id, // Pass product UUID for stock reduction trigger
          product_name: item.name,
          product_price: item.price,
          quantity: item.quantity,
          total_price: item.price * item.quantity,
          payment_method: selectedPayment === "qris" ? "QRIS" : "Other",
          payment_status: "pending",
        }]);

        if (error) {
          console.error("Error saving order:", error);
          throw error;
        }
      }

      // Generate WhatsApp message
      const message = generateOrderMessage();
      const encodedMessage = encodeURIComponent(message);
      
      const whatsappNumber = settings.whatsapp_number || "6281368968924";
      const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;

      // Show success state
      setOrderSuccess(true);
      toast.success("Pesanan berhasil! Mengarahkan ke WhatsApp...");

      // Open WhatsApp after a short delay
      setTimeout(() => {
        window.open(whatsappUrl, "_blank");
      }, 1500);
    } catch (error) {
      console.error("Error processing order:", error);
      toast.error("Terjadi kesalahan, silakan coba lagi");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (orderSuccess) {
    return (
      <>
        <Helmet>
          <title>Pesanan Berhasil - Daqqu</title>
        </Helmet>
        <div className="min-h-screen bg-background">
          <Navbar cartItemCount={0} onCartClick={() => {}} />
          <main className="pt-24 pb-16">
            <div className="container mx-auto px-4 lg:px-8">
              <div className="max-w-lg mx-auto text-center py-16">
                <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle className="w-10 h-10 text-primary" />
                </div>
                <h1 className="text-3xl font-bold text-foreground mb-4">
                  Pesanan Berhasil!
                </h1>
                <p className="text-muted-foreground mb-8">
                  Terima kasih atas pesanan Anda. Silakan lanjutkan konfirmasi
                  pembayaran melalui WhatsApp.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button variant="default" onClick={() => navigate("/")}>
                    Kembali ke Beranda
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      const message = generateOrderMessage();
                      const encodedMessage = encodeURIComponent(message);
                      const whatsappNumber = settings.whatsapp_number || "6281368968924";
                      window.open(
                        `https://wa.me/${whatsappNumber}?text=${encodedMessage}`,
                        "_blank"
                      );
                    }}
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Buka WhatsApp
                  </Button>
                </div>
              </div>
            </div>
          </main>
          <Footer />
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Checkout - Daqqu</title>
        <meta name="description" content="Selesaikan pembelian Anda" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar cartItemCount={cartItems.length} onCartClick={() => {}} />

        <main className="pt-24 pb-16">
          <div className="container mx-auto px-4 lg:px-8">
            {/* Back Button */}
            <button
              onClick={() => navigate(-1)}
              className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-8"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Kembali</span>
            </button>

            <h1 className="text-3xl font-bold text-foreground mb-8">
              Checkout
            </h1>

            <div className="grid lg:grid-cols-3 gap-8">
              {/* Form Section */}
              <div className="lg:col-span-2 space-y-6">
                {/* Buyer Information */}
                <div className="bg-card border border-border rounded-xl p-6">
                  <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center gap-2">
                    <User className="w-5 h-5 text-primary" />
                    Data Pembeli
                  </h2>

                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Nama Lengkap *</Label>
                        <div className="relative">
                          <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                          <Input
                            id="name"
                            name="name"
                            placeholder="Masukkan nama lengkap"
                            value={formData.name}
                            onChange={handleInputChange}
                            className="pl-10"
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone">Nomor WhatsApp *</Label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                          <Input
                            id="phone"
                            name="phone"
                            type="tel"
                            placeholder="08xxxxxxxxxx"
                            value={formData.phone}
                            onChange={handleInputChange}
                            className="pl-10"
                            required
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          placeholder="email@contoh.com"
                          value={formData.email}
                          onChange={handleInputChange}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="address">Alamat (Opsional)</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                        <Textarea
                          id="address"
                          name="address"
                          placeholder="Masukkan alamat lengkap"
                          value={formData.address}
                          onChange={handleInputChange}
                          className="pl-10 min-h-[80px]"
                        />
                      </div>
                    </div>
                  </form>
                </div>

                {/* Payment Methods - QRIS Only */}
                <div className="bg-card border border-border rounded-xl p-6">
                  <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-primary" />
                    Metode Pembayaran
                  </h2>

                  <button
                    type="button"
                    onClick={() => setSelectedPayment(selectedPayment === "qris" ? "" : "qris")}
                    className={`w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all text-left ${
                      selectedPayment === "qris"
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    <div className="w-16 h-12 rounded-lg flex items-center justify-center bg-white p-1">
                      <img 
                        src={QRIS_LOGO_URL} 
                        alt="QRIS Logo" 
                        className="w-full h-full object-contain"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-foreground">QRIS</h3>
                      <p className="text-sm text-muted-foreground">
                        Scan QR untuk pembayaran instan
                      </p>
                    </div>
                    <div
                      className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                        selectedPayment === "qris"
                          ? "border-primary bg-primary"
                          : "border-muted-foreground"
                      }`}
                    >
                      {selectedPayment === "qris" && (
                        <div className="w-2 h-2 rounded-full bg-primary-foreground" />
                      )}
                    </div>
                  </button>

                  {/* QRIS Image Display */}
                  {selectedPayment === "qris" && (
                    <div className="mt-6 p-6 bg-white rounded-xl border border-border text-center">
                      <p className="text-sm text-muted-foreground mb-4">
                        Scan QR Code di bawah untuk melakukan pembayaran
                      </p>
                      <div className="inline-block p-4 bg-white rounded-xl shadow-lg">
                        <img
                          src={settings.qris_image_url || "/placeholder.svg"}
                          alt="QRIS Payment Code"
                          className="w-64 h-64 object-contain mx-auto"
                        />
                      </div>
                      <p className="text-xs text-muted-foreground mt-4">
                        Gunakan aplikasi e-wallet atau mobile banking untuk scan
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Order Summary */}
              <div className="lg:col-span-1">
                <div className="bg-card border border-border rounded-xl p-6 sticky top-24">
                  <h2 className="text-xl font-semibold text-foreground mb-6">
                    Ringkasan Pesanan
                  </h2>

                  <div className="space-y-4 mb-6">
                    {cartItems.map((item) => (
                      <div key={item.id} className="flex gap-3">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-foreground text-sm line-clamp-2">
                            {item.name}
                          </h4>
                          <p className="text-muted-foreground text-sm">
                            x{item.quantity}
                          </p>
                          <p className="text-primary font-semibold text-sm">
                            {formatPrice(item.price * item.quantity)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-border pt-4 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span className="text-foreground">
                        {formatPrice(total)}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Biaya Admin</span>
                      <span className="text-primary font-medium">Gratis</span>
                    </div>
                  </div>

                  <div className="border-t border-border mt-4 pt-4">
                    <div className="flex justify-between items-center mb-6">
                      <span className="font-semibold text-foreground">
                        Total
                      </span>
                      <span className="text-2xl font-bold text-primary">
                        {formatPrice(total)}
                      </span>
                    </div>

                    <Button
                      size="lg"
                      className="w-full bg-[#25D366] hover:bg-[#128C7E] text-white"
                      onClick={handleSubmit}
                      disabled={isSubmitting}
                    >
                      <svg 
                        className="w-5 h-5 mr-2" 
                        viewBox="0 0 24 24" 
                        fill="currentColor"
                      >
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                      </svg>
                      {isSubmitting ? "Memproses..." : "Konfirmasi Via WhatsApp"}
                    </Button>

                    <p className="text-xs text-muted-foreground text-center mt-4">
                      Pesanan akan dikonfirmasi melalui WhatsApp
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default Checkout;
