import { useState } from "react";
import { Helmet } from "react-helmet-async";
import { toast } from "sonner";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import ProductSection from "@/components/ProductSection";
import HowToSubscribeSection from "@/components/HowToSubscribeSection";
import FAQSection from "@/components/FAQSection";
import CartSidebar, { CartItem } from "@/components/CartSidebar";
import Footer from "@/components/Footer";
import RecentPurchasePopup from "@/components/RecentPurchasePopup";
import { Product } from "@/components/ProductCard";
import { useWebsiteSettings } from "@/hooks/useWebsiteSettings";

const Index = () => {
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const { settings } = useWebsiteSettings();

  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const existingItem = prev.find((item) => item.id === product.id);
      if (existingItem) {
        toast.success(`Jumlah ${product.name} ditambahkan`);
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      toast.success(`${product.name} ditambahkan ke keranjang`);
      const newItem: CartItem = {
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        quantity: 1,
      };
      return [...prev, newItem];
    });
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity < 1) return;
    setCartItems((prev) =>
      prev.map((item) => (item.id === productId ? { ...item, quantity } : item))
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== productId));
    toast.info("Produk dihapus dari keranjang");
  };

  const cartItemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <>
      <Helmet>
        <title>{settings.site_name} - Marketplace AI Tools Terlengkap</title>
        <meta
          name="description"
          content="Dapatkan akses premium ke tools AI terbaik dengan harga terjangkau. ChatGPT, Midjourney, Canva Pro, dan banyak lagi."
        />
      </Helmet>

      <div className="min-h-screen bg-background">
        <Navbar cartItemCount={cartItemCount} onCartClick={() => setCartOpen(true)} />
        <Hero />
        <ProductSection onAddToCart={handleAddToCart} />
        <HowToSubscribeSection />
        <FAQSection />
        <Footer />
        <CartSidebar
          isOpen={cartOpen}
          onClose={() => setCartOpen(false)}
          items={cartItems}
          onUpdateQuantity={handleUpdateQuantity}
          onRemoveItem={handleRemoveItem}
        />
        <RecentPurchasePopup />
      </div>
    </>
  );
};

export default Index;
