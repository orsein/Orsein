import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

interface WebsiteSettings {
  logo_url: string;
  qris_image_url: string;
  whatsapp_number: string;
  site_name: string;
  primary_color: string;
}

const defaultSettings: WebsiteSettings = {
  logo_url: "",
  qris_image_url: "",
  whatsapp_number: "6281368968924", // Default: 081368968924
  site_name: "Daqqu",
  primary_color: "#002b2f",
};

// Convert HEX to HSL
const hexToHSL = (hex: string): string => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!result) return "184 100% 9%"; // fallback - dark cyan

  let r = parseInt(result[1], 16) / 255;
  let g = parseInt(result[2], 16) / 255;
  let b = parseInt(result[3], 16) / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r:
        h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
        break;
      case g:
        h = ((b - r) / d + 2) / 6;
        break;
      case b:
        h = ((r - g) / d + 4) / 6;
        break;
    }
  }

  return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
};

// Apply theme color to CSS variables
const applyThemeColor = (hexColor: string) => {
  const hsl = hexToHSL(hexColor);
  document.documentElement.style.setProperty("--primary", hsl);
  
  // Create lighter/darker variants
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hexColor);
  if (result) {
    let r = parseInt(result[1], 16) / 255;
    let g = parseInt(result[2], 16) / 255;
    let b = parseInt(result[3], 16) / 255;
    
    // Determine if color is light or dark for foreground
    const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
    const foregroundHsl = luminance > 0.5 ? "0 0% 0%" : "0 0% 100%";
    document.documentElement.style.setProperty("--primary-foreground", foregroundHsl);
  }
};

// Apply favicon from logo URL
const applyFavicon = (logoUrl: string) => {
  if (!logoUrl) return;
  
  let link = document.querySelector("link[rel='icon']") as HTMLLinkElement;
  if (!link) {
    link = document.createElement('link');
    link.rel = 'icon';
    document.head.appendChild(link);
  }
  link.href = logoUrl;
  link.type = 'image/png';
};

export const useWebsiteSettings = () => {
  const [settings, setSettings] = useState<WebsiteSettings>(defaultSettings);
  const [isLoading, setIsLoading] = useState(true);

  const fetchSettings = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from("website_settings")
        .select("key, value");

      if (error) throw error;

      if (data) {
        const settingsMap: Record<string, string> = {};
        data.forEach((item) => {
          settingsMap[item.key] = item.value || "";
        });

        const newSettings = {
          logo_url: settingsMap.logo_url || defaultSettings.logo_url,
          qris_image_url: settingsMap.qris_image_url || defaultSettings.qris_image_url,
          whatsapp_number: settingsMap.whatsapp_number || defaultSettings.whatsapp_number,
          site_name: settingsMap.site_name || defaultSettings.site_name,
          primary_color: settingsMap.primary_color || defaultSettings.primary_color,
        };

        setSettings(newSettings);
        
        // Apply theme color
        if (newSettings.primary_color) {
          applyThemeColor(newSettings.primary_color);
        }
        
        // Apply favicon from logo
        if (newSettings.logo_url) {
          applyFavicon(newSettings.logo_url);
        }
      }
    } catch (error) {
      console.error("Error fetching settings:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSettings();

    // Subscribe to realtime changes
    const channel = supabase
      .channel("website_settings_changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "website_settings",
        },
        () => {
          fetchSettings();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchSettings]);

  return { settings, isLoading, refetch: fetchSettings };
};
