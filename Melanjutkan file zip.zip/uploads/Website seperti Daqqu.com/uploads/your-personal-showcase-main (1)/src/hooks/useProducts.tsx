import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";

export type DbProduct = Database["public"]["Tables"]["products"]["Row"];

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: string;
  image: string;
  badge?: string;
}

export interface ProductWithDetails extends Product {
  fullDescription: string;
  rating: number;
  images: string[];
  features: string[];
  stock: number;
  specifications?: { label: string; value: string }[];
}

// Transform database product to frontend format
const transformProduct = (dbProduct: DbProduct): Product => ({
  id: dbProduct.id,
  name: dbProduct.name,
  description: dbProduct.description || "",
  price: dbProduct.price,
  originalPrice: dbProduct.original_price || undefined,
  category: dbProduct.category,
  image: dbProduct.images?.[0] || "/placeholder.svg",
  badge: dbProduct.badge || undefined,
});

const transformProductWithDetails = (dbProduct: DbProduct): ProductWithDetails => ({
  id: dbProduct.id,
  name: dbProduct.name,
  description: dbProduct.description || "",
  fullDescription: dbProduct.full_description || "",
  price: dbProduct.price,
  originalPrice: dbProduct.original_price || undefined,
  category: dbProduct.category,
  image: dbProduct.images?.[0] || "/placeholder.svg",
  images: dbProduct.images || [],
  badge: dbProduct.badge || undefined,
  features: dbProduct.features || [],
  stock: dbProduct.stock,
  rating: 5, // Default rating since we don't have reviews in DB yet
  specifications: (dbProduct.specifications as { label: string; value: string }[]) || [],
});

export const useProducts = () => {
  return useQuery({
    queryKey: ["products"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("*")
        .eq("is_active", true)
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Error fetching products:", error);
        throw error;
      }

      return (data || []).map(transformProduct);
    },
  });
};

export const useProductById = (id: string) => {
  return useQuery({
    queryKey: ["product", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("*")
        .eq("id", id)
        .eq("is_active", true)
        .single();

      if (error) {
        console.error("Error fetching product:", error);
        throw error;
      }

      return transformProductWithDetails(data);
    },
    enabled: !!id,
  });
};
