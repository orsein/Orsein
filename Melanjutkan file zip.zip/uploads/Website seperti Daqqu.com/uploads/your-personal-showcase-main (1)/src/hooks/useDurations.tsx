import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface DurationOption {
  id: string;
  label: string;
  multiplier: number;
  sort_order: number;
  is_active: boolean;
}

export const useDurations = () => {
  return useQuery({
    queryKey: ["durations"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("duration_options")
        .select("*")
        .eq("is_active", true)
        .order("sort_order", { ascending: true });

      if (error) throw error;
      return data as DurationOption[];
    },
  });
};

export const useAllDurations = () => {
  return useQuery({
    queryKey: ["all-durations"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("duration_options")
        .select("*")
        .order("sort_order", { ascending: true });

      if (error) throw error;
      return data as DurationOption[];
    },
  });
};

export const useCreateDuration = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (duration: Omit<DurationOption, "id">) => {
      const { data, error } = await supabase
        .from("duration_options")
        .insert(duration)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["all-durations"] });
      queryClient.invalidateQueries({ queryKey: ["durations"] });
      toast.success("Durasi berhasil ditambahkan");
    },
    onError: (error) => {
      toast.error("Gagal menambahkan durasi: " + error.message);
    },
  });
};

export const useUpdateDuration = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, ...updates }: Partial<DurationOption> & { id: string }) => {
      const { data, error } = await supabase
        .from("duration_options")
        .update(updates)
        .eq("id", id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["all-durations"] });
      queryClient.invalidateQueries({ queryKey: ["durations"] });
      toast.success("Durasi berhasil diperbarui");
    },
    onError: (error) => {
      toast.error("Gagal memperbarui durasi: " + error.message);
    },
  });
};

export const useDeleteDuration = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("duration_options")
        .delete()
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["all-durations"] });
      queryClient.invalidateQueries({ queryKey: ["durations"] });
      toast.success("Durasi berhasil dihapus");
    },
    onError: (error) => {
      toast.error("Gagal menghapus durasi: " + error.message);
    },
  });
};
